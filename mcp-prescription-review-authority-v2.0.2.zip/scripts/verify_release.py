from __future__ import annotations

import csv
import hashlib
import json
import os
import sys
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "MANIFEST_SHA256.csv"
SOURCE_MANIFEST = ROOT / "data/public/source_manifest.json"
LEGACY_DIR = ROOT / "legacy/public_synthetic_20260728"
LEGACY_MANIFEST = LEGACY_DIR / "SOURCE_MANIFEST.json"
IGNORED_DIRS = {".git", ".venv", "__pycache__", ".pytest_cache"}
LEGACY_PATHS = {
    "synthetic_lab_prescriptions_660.jsonl", "prepared_mcp_contexts_660.jsonl",
    *(f"models/{model}/{name}"
      for model in ("qwen2.5-3b", "smollm2-1.7b", "phi3.5-mini")
      for name in ("batch1_repeat0_scores.json", "batch8_repeat1_scores.json",
                   "batch8_repeat2_scores.json", "main_scores.json", "predictions.csv",
                   "raw_scores_and_stability.json")),
}
class CheckError(RuntimeError):
    pass
def safe_path(base: Path, relative: str) -> Path:
    pure = PurePosixPath(relative)
    if (not relative or "\\" in relative or ":" in relative or pure.is_absolute()
            or ".." in pure.parts or pure.as_posix() != relative):
        raise CheckError(f"unsafe path: {relative!r}")
    path = base.joinpath(*pure.parts)
    try:
        path.resolve().relative_to(base.resolve())
    except ValueError as exc:
        raise CheckError(f"path escapes root: {relative}") from exc
    return path
def file_hashes(path: Path) -> tuple[int, str, str]:
    if not path.is_file():
        raise CheckError(f"missing file: {path}")
    size = path.stat().st_size
    sha256, git_blob = hashlib.sha256(), hashlib.sha1()
    git_blob.update(f"blob {size}\0".encode())
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            sha256.update(chunk)
            git_blob.update(chunk)
    return size, sha256.hexdigest(), git_blob.hexdigest()
def check_file(path: Path, size: int, sha256: str, git_blob: str | None = None) -> None:
    actual = file_hashes(path)
    if actual[:2] != (size, sha256) or (git_blob and actual[2] != git_blob):
        raise CheckError(f"hash or size mismatch: {path}")
def load_legacy_entries() -> list[tuple[str, int, str, str]]:
    items = json.loads(LEGACY_MANIFEST.read_text(encoding="utf-8-sig"))["files"]
    entries = [(x["path"], int(x["size_bytes"]), x["sha256"], x["git_blob_sha"]) for x in items]
    paths = [x[0] for x in entries]
    if len(paths) != 20 or len({x.casefold() for x in paths}) != 20 or set(paths) != LEGACY_PATHS:
        raise CheckError("legacy manifest must contain the fixed 20 paths")
    return entries
def verify_manifest() -> dict[str, tuple[int, str]]:
    with MANIFEST.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != ["path", "size_bytes", "sha256"]:
            raise CheckError("manifest columns must be path,size_bytes,sha256")
        rows = list(reader)
    listed, folded = {}, set()
    for row in rows:
        relative, key = row["path"], row["path"].casefold()
        parts = PurePosixPath(relative).parts
        if key in folded or relative == MANIFEST.name or any(x in IGNORED_DIRS for x in parts):
            raise CheckError(f"duplicate or ineligible manifest path: {relative}")
        folded.add(key)
        expected = int(row["size_bytes"]), row["sha256"]
        check_file(safe_path(ROOT, relative), *expected)
        listed[relative] = expected
    actual = set()
    for directory, dirs, files in os.walk(ROOT):
        dirs[:] = [x for x in dirs if x not in IGNORED_DIRS]
        for name in files:
            path = Path(directory) / name
            relative = path.relative_to(ROOT).as_posix()
            if relative != MANIFEST.name and path.suffix.lower() not in {".pyc", ".pyo"}:
                actual.add(relative)
    unlisted = sorted(actual - listed.keys())
    if unlisted:
        raise CheckError(f"unlisted release files ({len(unlisted)}): {', '.join(unlisted[:5])}")
    return listed
def verify_nested(listed: dict[str, tuple[int, str]]) -> tuple[int, int]:
    sources = json.loads(SOURCE_MANIFEST.read_text(encoding="utf-8-sig"))["files"]
    if not isinstance(sources, dict) or len(sources) != 4:
        raise CheckError("public source manifest must contain four files")
    for name, item in sources.items():
        if PurePosixPath(name).name != name:
            raise CheckError(f"invalid public source filename: {name}")
        relative = f"data/public/raw/{name}"
        expected = int(item["bytes"]), item["sha256"]
        check_file(safe_path(ROOT, relative), *expected)
        if listed.get(relative) != expected:
            raise CheckError(f"source manifest disagrees with main manifest: {relative}")
    legacy = load_legacy_entries()
    for relative, size, sha256, git_blob in legacy:
        check_file(safe_path(LEGACY_DIR, relative), size, sha256, git_blob)
        release_path = f"legacy/public_synthetic_20260728/{relative}"
        if listed.get(release_path) != (size, sha256):
            raise CheckError(f"legacy manifest disagrees with main manifest: {release_path}")
    return len(sources), len(legacy)
def main() -> int:
    if len(sys.argv) != 1:
        print("FAIL: verify_release.py takes no arguments", file=sys.stderr)
        return 2
    try:
        listed = verify_manifest()
        source_count, legacy_count = verify_nested(listed)
    except (CheckError, OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print(f"PASS: {len(listed)} release files, {source_count} public sources, {legacy_count} legacy files")
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
