from __future__ import annotations

import argparse
import copy
import csv
import io
import json
import math
import random
import sys
import time
import zipfile
from collections import defaultdict
from dataclasses import replace
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from prescription_mcp.orchestrator import PrescriptionReviewOrchestrator


MODEL_ID = "Qwen/Qwen2.5-0.5B-Instruct"
DOMAINS = ("ceftazidime", "nifedipine extended-release", "warfarin")


def load_demographics() -> list[dict]:
    source = ROOT / "data/public/raw/synthea_sample_data_csv_apr2020.zip"
    with zipfile.ZipFile(source) as archive:
        rows = list(csv.DictReader(io.TextIOWrapper(archive.open("csv/patients.csv"), encoding="utf-8-sig")))
    adults = []
    for row in rows:
        born = date.fromisoformat(row["BIRTHDATE"])
        age = 2025 - born.year
        if age >= 18:
            adults.append({"age": age, "sex": row["GENDER"]})
    return adults


def build_corpus() -> list[dict]:
    rng = random.Random(20260727)
    demographics = load_demographics()
    rng.shuffle(demographics)
    cases = []
    for index in range(300):
        domain = DOMAINS[index // 100]
        positive = index % 100 < 50
        patient = {"id": f"SYN-{index + 1:03d}", **demographics[index], "weight_kg": rng.randint(50, 95), "allergies": []}
        if domain == "ceftazidime":
            payload, scenario = ceftazidime_case(patient, positive, index, rng)
        elif domain == "nifedipine extended-release":
            payload, scenario = nifedipine_case(patient, positive, index)
        else:
            payload, scenario = warfarin_case(patient, positive, index)
        cases.append({
            "case_id": f"SYN-{index + 1:03d}",
            "domain": domain,
            "scenario": scenario,
            "reference": "review required" if positive else "approved",
            "synthetic": True,
            "payload": payload,
        })
    return cases


def ceftazidime_case(patient: dict, positive: bool, index: int, rng: random.Random) -> tuple[dict, str]:
    patient = copy.deepcopy(patient)
    if positive and index % 2 == 0:
        patient["egfr"] = rng.uniform(18, 48)
        scenario = "renal threshold positive"
    elif positive:
        patient["egfr"] = rng.uniform(60, 95)
        patient["allergies"] = [{"drug": "penicillin", "reaction": "anaphylaxis", "severity": "high"}]
        scenario = "allergy positive"
    else:
        patient["egfr"] = rng.uniform(60, 110)
        if index % 2:
            patient["allergies"] = [{"drug": "metformin", "reaction": "rash", "severity": "low"}]
        scenario = "renal and allergy negative"
    payload = {
        "id": patient["id"], "patient": patient, "review_targets": ["ceftazidime"],
        "medications": [{"drug": "ceftazidime", "dose_mg": 1000, "frequency": "q8h", "dose_unit": "mg"}],
    }
    return payload, scenario


def nifedipine_case(patient: dict, positive: bool, index: int) -> tuple[dict, str]:
    administration = ("tablet " + ("crushed" if index % 4 == 0 else "split")) if positive else "swallowed whole"
    payload = {
        "id": patient["id"], "patient": patient, "review_targets": ["nifedipine GITS"],
        "medications": [{"drug": "nifedipine GITS", "dose_mg": 30, "frequency": "qd", "dose_unit": "mg", "formulation": "extended_release", "administration": administration}],
    }
    return payload, "altered formulation positive" if positive else "intact formulation negative"


def warfarin_case(patient: dict, positive: bool, index: int) -> tuple[dict, str]:
    medications = [{"drug": "warfarin", "dose_mg": 3, "frequency": "qd", "dose_unit": "mg"}]
    if positive:
        medications.append({"drug": "ibuprofen", "dose_mg": 400, "frequency": "tid", "dose_unit": "mg"})
    elif index % 2:
        medications.append({"drug": "amlodipine", "dose_mg": 5, "frequency": "qd", "dose_unit": "mg"})
    payload = {"id": patient["id"], "patient": patient, "review_targets": ["warfarin"], "medications": medications}
    return payload, "warfarin NSAID positive" if positive else "NSAID interaction negative"


class LocalQwen:
    def __init__(self, model_id: str) -> None:
        import torch
        import transformers
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.torch = torch
        self.environment = {
            "torch_version": torch.__version__,
            "transformers_version": transformers.__version__,
            "cuda_device": torch.cuda.get_device_name(0),
            "dtype": "bfloat16",
            "scoring": "mean candidate-token log likelihood",
            "sampling": "none (forced choice)",
            "batch_size": 24,
        }
        self.tokenizer = AutoTokenizer.from_pretrained(model_id, padding_side="left")
        self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model = AutoModelForCausalLM.from_pretrained(
            model_id, dtype=torch.bfloat16, device_map="cuda", attn_implementation="sdpa"
        ).eval()

    def choose(self, prompts: list[str], choices: tuple[str, str], batch_size: int = 24) -> tuple[list[str], list[float]]:
        prefixes = [self.tokenizer.apply_chat_template([{"role": "user", "content": prompt}], tokenize=False, add_generation_prompt=True) for prompt in prompts]
        candidates = [(prefix + choice, choice) for prefix in prefixes for choice in choices]
        scores = []
        for start in range(0, len(candidates), batch_size):
            batch = candidates[start:start + batch_size]
            texts = [item[0] for item in batch]
            candidate_lengths = []
            for text, choice in batch:
                full_ids = self.tokenizer(text, add_special_tokens=False)["input_ids"]
                prefix_ids = self.tokenizer(text[:-len(choice)], add_special_tokens=False)["input_ids"]
                candidate_lengths.append(len(full_ids) - len(prefix_ids))
            encoded = self.tokenizer(texts, return_tensors="pt", padding=True, add_special_tokens=False).to(self.model.device)
            with self.torch.inference_mode():
                logits = self.model(**encoded).logits.float().log_softmax(dim=-1)
            width = encoded["input_ids"].shape[1]
            for row, candidate_length in enumerate(candidate_lengths):
                token_scores = []
                for position in range(width - candidate_length, width):
                    token_id = encoded["input_ids"][row, position]
                    token_scores.append(logits[row, position - 1, token_id].item())
                scores.append(sum(token_scores) / len(token_scores))
        selected, margins = [], []
        for index in range(0, len(scores), 2):
            pair = scores[index:index + 2]
            winner = 0 if pair[0] >= pair[1] else 1
            selected.append(choices[winner])
            margins.append(round(abs(pair[0] - pair[1]), 6))
        return selected, margins


def label_rules(orchestrator: PrescriptionReviewOrchestrator, domain: str) -> str:
    return "\n".join(f"- {rule.condition_text} Action: {rule.action_text}" for rule in orchestrator.registry.rules_for([domain]))


def raw_case_text(case: dict) -> str:
    return json.dumps(case["payload"], ensure_ascii=False, sort_keys=True)


def evaluate(cases: list[dict], model_id: str) -> tuple[list[dict], dict]:
    orchestrator = PrescriptionReviewOrchestrator()
    qwen = LocalQwen(model_id)
    raw_prompts = [
        "You are reviewing a synthetic prescription. Use the supplied label rules and patient record. "
        "Return exactly REVIEW_REQUIRED or APPROVED as the first line.\n"
        f"Label rules:\n{label_rules(orchestrator, case['domain'])}\nRecord:\n{raw_case_text(case)}"
        for case in cases
    ]
    started = time.perf_counter()
    raw_outputs, raw_margins = qwen.choose(raw_prompts, ("REVIEW_REQUIRED", "APPROVED"))
    raw_seconds = time.perf_counter() - started

    prepared = []
    constrained_prompts = []
    for case in cases:
        deterministic = orchestrator.review(case["payload"], force_fallback=True)
        parsed = orchestrator.emr.build_prescription(case["payload"])
        targets, context, issues = orchestrator._resolve_targets(parsed)
        normalized = replace(parsed, medications=targets + context)
        indicators = orchestrator._construct_indicators(normalized, [])
        rules = orchestrator.kb.retrieve_rules([item.drug for item in targets], indicators)
        prompt_indexes = []
        for rule in rules:
            for indicator in indicators:
                if rule.rule_type == "numeric":
                    continue
                prompt_indexes.append(len(constrained_prompts))
                constrained_prompts.append(
                    "Decide only whether the supplied rule applies to the supplied indicator. "
                    "Do not use outside medical knowledge. Return exactly MATCH or NO_MATCH as the first line.\n"
                    f"Rule: {rule.condition_text}\nIndicator: {indicator.name} = {indicator.value}"
                )
        prepared.append((deterministic, rules, indicators, issues, prompt_indexes))
    started = time.perf_counter()
    constrained_outputs, constrained_margins = qwen.choose(constrained_prompts, ("MATCH", "NO_MATCH"))
    constrained_seconds = time.perf_counter() - started

    rows = []
    for case, raw_output, raw_margin, state in zip(cases, raw_outputs, raw_margins, prepared):
        deterministic, rules, indicators, issues, prompt_indexes = state
        raw_prediction = "review required" if raw_output == "REVIEW_REQUIRED" else "approved"
        semantic_match = any(constrained_outputs[i] == "MATCH" for i in prompt_indexes)
        deterministic_match = deterministic["status"] != "approved"
        constrained_prediction = "review required" if issues or deterministic_match or semantic_match else "approved"
        constrained_margin = min((constrained_margins[i] for i in prompt_indexes), default=None)
        for method, prediction, output, margin in [
            ("deterministic_rules", "review required" if deterministic_match else "approved", "", None),
            ("unconstrained_qwen", raw_prediction, raw_output, raw_margin),
            ("mcp_constrained_qwen", constrained_prediction, " | ".join(constrained_outputs[i] for i in prompt_indexes), constrained_margin),
        ]:
            rows.append({
                "case_id": case["case_id"], "domain": case["domain"], "scenario": case["scenario"],
                "reference": case["reference"], "method": method, "prediction": prediction,
                "forced_choice": output, "score_margin": margin,
            })
    timing = {
        "unconstrained_seconds": raw_seconds,
        "constrained_seconds": constrained_seconds,
        "model_id": model_id,
        **qwen.environment,
    }
    return rows, timing


def wilson(successes: int, total: int) -> list[float | None]:
    if total == 0:
        return [None, None]
    z = 1.959963984540054
    p = successes / total
    denominator = 1 + z * z / total
    centre = (p + z * z / (2 * total)) / denominator
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total) / denominator
    return [round(centre - margin, 4), round(centre + margin, 4)]


def summarize(rows: list[dict]) -> list[dict]:
    groups = defaultdict(list)
    for row in rows:
        groups[(row["method"], row["domain"])].append(row)
        groups[(row["method"], "overall")].append(row)
    summary = []
    for (method, domain), items in sorted(groups.items()):
        tp = sum(x["reference"] == "review required" and x["prediction"] == "review required" for x in items)
        tn = sum(x["reference"] == "approved" and x["prediction"] == "approved" for x in items)
        fp = sum(x["reference"] == "approved" and x["prediction"] == "review required" for x in items)
        fn = sum(x["reference"] == "review required" and x["prediction"] == "approved" for x in items)
        summary.append({
            "method": method, "domain": domain, "n": len(items), "tp": tp, "tn": tn, "fp": fp, "fn": fn,
            "accuracy": round((tp + tn) / len(items), 4),
            "sensitivity": round(tp / (tp + fn), 4), "sensitivity_95ci": wilson(tp, tp + fn),
            "specificity": round(tn / (tn + fp), 4), "specificity_95ci": wilson(tn, tn + fp),
        })
    return summary


def stress_test(cases: list[dict]) -> list[dict]:
    selected = [case for domain in DOMAINS for case in [x for x in cases if x["domain"] == domain][:10]]
    selected += [case for domain in DOMAINS for case in [x for x in cases if x["domain"] == domain][50:60]]
    faults = ("missing_field", "unit_error", "retrieval_omission", "conflicting_labels", "mcp_service_failure")
    results = []
    for fault in faults:
        for case in selected:
            payload = copy.deepcopy(case["payload"])
            orchestrator = PrescriptionReviewOrchestrator()
            if fault == "missing_field":
                payload["medications"][0].pop("dose_mg", None)
            elif fault == "unit_error":
                payload["medications"][0]["dose_unit"] = "g"
            elif fault == "retrieval_omission":
                orchestrator.kb.retrieve_rules = lambda *_: []
            elif fault == "conflicting_labels":
                original = orchestrator.kb.retrieve_rules
                def conflict(*args):
                    rules = original(*args)
                    if not rules:
                        return rules
                    return rules + [replace(rules[0], id=rules[0].id + "-CONFLICT", action_text="No pharmacist review is required.")]
                orchestrator.kb.retrieve_rules = conflict
            else:
                def fail(*_):
                    raise RuntimeError("injected MCP service failure")
                orchestrator.kb.retrieve_rules = fail
            result = orchestrator.review(payload)
            results.append({"fault": fault, "case_id": case["case_id"], "domain": case["domain"], "status": result["status"], "coverage_status": result["coverage_status"], "safe_escalation": result["status"] == "review required"})
    return results


def write_outputs(cases: list[dict], rows: list[dict], timing: dict, stress: list[dict], output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    with (output / "synthetic_prescription_benchmark_300.jsonl").open("w", encoding="utf-8") as handle:
        for case in cases:
            handle.write(json.dumps(case, ensure_ascii=False) + "\n")
    for name, data in [("three_path_predictions.csv", rows), ("stress_test_predictions.csv", stress)]:
        with (output / name).open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=data[0].keys())
            writer.writeheader()
            writer.writerows(data)
    stress_summary = []
    for fault in sorted({row["fault"] for row in stress}):
        subset = [row for row in stress if row["fault"] == fault]
        successes = sum(row["safe_escalation"] for row in subset)
        stress_summary.append({"fault": fault, "n": len(subset), "safe_escalations": successes, "rate": successes / len(subset), "rate_95ci": wilson(successes, len(subset))})
    report = {"corpus": {"n": len(cases), "domains": {domain: sum(c["domain"] == domain for c in cases) for domain in DOMAINS}, "clinical_records": 0}, "timing": timing, "comparison": summarize(rows), "stress": stress_summary}
    (output / "public_system_comparison_summary.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default=MODEL_ID)
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/public_system_comparison")
    args = parser.parse_args()
    cases = build_corpus()
    rows, timing = evaluate(cases, args.model)
    stress = stress_test(cases)
    write_outputs(cases, rows, timing, stress, args.output)
    print(json.dumps(json.loads((args.output / "public_system_comparison_summary.json").read_text(encoding="utf-8")), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
