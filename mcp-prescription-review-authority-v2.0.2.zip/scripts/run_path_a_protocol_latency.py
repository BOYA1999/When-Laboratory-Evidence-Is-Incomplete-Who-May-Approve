from __future__ import annotations

import asyncio
import csv
import hashlib
import importlib.metadata
import json
import os
import platform
import statistics
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from prescription_mcp.orchestrator import PrescriptionReviewOrchestrator  # noqa: E402


OUT = ROOT / "outputs" / "path_a_protocol_latency_20260904"
SERVER = ROOT / "mcp_server.py"
FAULT_SERVER = ROOT / "tests" / "faulty_mcp_server.py"
WARMUP, WARM_N, COLD_N, RECOVERY_N = 20, 500, 20, 10
CONTEXT_KEYS = {"patient_context", "medications", "laboratory_evidence", "data_quality_notices", "rules"}
REVIEW_KEYS = {"status", "coverage_status", "coverage_issues"}


def payload():
    return {
        "id": "PUBLIC-SYNTHETIC-LATENCY-CONTROL",
        "patient": {
            "encounter_id": "SYNTHETIC-ENCOUNTER",
            "review_time": "2026-07-28T08:00:00Z",
            "labs": [{
                "name": "potassium",
                "value": 4.4,
                "unit": "mEq/L",
                "collected_at": "2026-07-27T08:00:00Z",
                "encounter_id": "SYNTHETIC-ENCOUNTER",
            }],
        },
        "review_targets": ["spironolactone"],
        "medications": [{"drug": "spironolactone", "dose_mg": 25, "frequency": "qd"}],
    }


def ms(start):
    return (time.perf_counter_ns() - start) / 1_000_000


def quantile(values, fraction):
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    low = int(position)
    high = min(low + 1, len(ordered) - 1)
    return ordered[low] + (ordered[high] - ordered[low]) * (position - low)


def summary_row(condition, operation, values):
    q1, q3 = quantile(values, 0.25), quantile(values, 0.75)
    return {
        "condition": condition,
        "operation": operation,
        "n": len(values),
        "median_ms": round(statistics.median(values), 3),
        "q1_ms": round(q1, 3),
        "q3_ms": round(q3, 3),
        "iqr_ms": round(q3 - q1, 3),
        "p95_ms": round(quantile(values, 0.95), 3),
        "min_ms": round(min(values), 3),
        "max_ms": round(max(values), 3),
    }


def validate(result, required):
    content = getattr(result, "structuredContent", None)
    if getattr(result, "isError", False) or not isinstance(content, dict) or not required.issubset(content):
        raise RuntimeError("invalid MCP structured result")
    return content


def signature(review):
    return {
        "status": review["status"],
        "coverage_status": review["coverage_status"],
        "coverage_issues": review["coverage_issues"],
        "matched_rule_ids": sorted(item["rule_id"] for item in review["matched_alerts"]),
    }


def server_params(path):
    from mcp import StdioServerParameters

    return StdioServerParameters(command=sys.executable, args=[str(path), "--transport", "stdio"], cwd=ROOT)


def measure_direct(item):
    orchestrator = PrescriptionReviewOrchestrator()
    context_ms, review_ms = [], []
    context = review = None
    for index in range(WARMUP + WARM_N):
        started = time.perf_counter_ns()
        context = orchestrator.lab_review_context(item)
        context_elapsed = ms(started)
        started = time.perf_counter_ns()
        review = orchestrator.review(item, force_fallback=True)
        review_elapsed = ms(started)
        if index >= WARMUP:
            context_ms.append(context_elapsed)
            review_ms.append(review_elapsed)
    return context_ms, review_ms, context, review


async def measure_warm_mcp(item):
    from mcp import ClientSession
    from mcp.client.stdio import stdio_client

    context_ms, review_ms = [], []
    context = review = None
    with open(os.devnull, "w", encoding="utf-8") as errlog:
        async with stdio_client(server_params(SERVER), errlog=errlog) as streams:
            async with ClientSession(*streams) as session:
                await session.initialize()
                for index in range(WARMUP + WARM_N):
                    started = time.perf_counter_ns()
                    context = validate(
                        await session.call_tool("get_lab_review_context", {"payload": item}),
                        CONTEXT_KEYS,
                    )
                    context_elapsed = ms(started)
                    started = time.perf_counter_ns()
                    review = validate(
                        await session.call_tool(
                            "review_prescription",
                            {"payload": item, "force_fallback": True},
                        ),
                        REVIEW_KEYS,
                    )
                    review_elapsed = ms(started)
                    if index >= WARMUP:
                        context_ms.append(context_elapsed)
                        review_ms.append(review_elapsed)
    return context_ms, review_ms, context, review


async def measure_cold_initialization():
    from mcp import ClientSession
    from mcp.client.stdio import stdio_client

    values = []
    with open(os.devnull, "w", encoding="utf-8") as errlog:
        for _ in range(COLD_N):
            started = time.perf_counter_ns()
            async with stdio_client(server_params(SERVER), errlog=errlog) as streams:
                async with ClientSession(*streams) as session:
                    await session.initialize()
                    values.append(ms(started))
    return values


async def interrupt(item):
    from mcp import ClientSession
    from mcp.client.stdio import stdio_client

    faulty = {**item, "_fault": "exit_review"}
    call_started = 0
    try:
        with open(os.devnull, "w", encoding="utf-8") as errlog:
            async with stdio_client(server_params(FAULT_SERVER), errlog=errlog) as streams:
                async with ClientSession(*streams) as session:
                    await session.initialize()
                    call_started = time.perf_counter_ns()
                    await session.call_tool("review_prescription", {"payload": faulty, "force_fallback": True})
    except BaseException as exc:
        if not call_started:
            raise RuntimeError("fault fixture failed before the interruption call") from exc
        return ms(call_started), type(exc).__name__
    raise RuntimeError("fault fixture did not interrupt the server")


async def recover(item):
    from mcp import ClientSession
    from mcp.client.stdio import stdio_client

    started = time.perf_counter_ns()
    with open(os.devnull, "w", encoding="utf-8") as errlog:
        async with stdio_client(server_params(SERVER), errlog=errlog) as streams:
            async with ClientSession(*streams) as session:
                await session.initialize()
                validate(await session.call_tool("get_lab_review_context", {"payload": item}), CONTEXT_KEYS)
                validate(
                    await session.call_tool("review_prescription", {"payload": item, "force_fallback": True}),
                    REVIEW_KEYS,
                )
                return ms(started)


async def measure_recovery(item):
    fault_ms, recovery_ms, total_ms, exceptions = [], [], [], Counter()
    for _ in range(RECOVERY_N):
        fault, error_type = await interrupt(item)
        recovered = await recover(item)
        fault_ms.append(fault)
        recovery_ms.append(recovered)
        total_ms.append(fault + recovered)
        exceptions[error_type] += 1
    return fault_ms, recovery_ms, total_ms, exceptions


def environment():
    import psutil

    processor = platform.processor() or "unavailable"
    if platform.system() == "Windows":
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as key:
                processor = str(winreg.QueryValueEx(key, "ProcessorNameString")[0]).strip()
        except OSError:
            pass
    return {
        "os": platform.platform(),
        "machine": platform.machine(),
        "processor": processor,
        "physical_cores": psutil.cpu_count(logical=False),
        "logical_cores": psutil.cpu_count(logical=True),
        "ram_gib": round(psutil.virtual_memory().total / 1024**3, 1),
        "python_implementation": platform.python_implementation(),
        "python_version": platform.python_version(),
        "python_executable_name": Path(sys.executable).name,
        "mcp_sdk_version": importlib.metadata.version("mcp"),
        "timer": "time.perf_counter_ns",
    }


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_command():
    try:
        executable = Path(sys.executable).resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        executable = "python"
    return f"{executable} scripts/run_path_a_protocol_latency.py"


def write_results(rows, exceptions):
    if OUT.exists() and any(OUT.iterdir()):
        raise FileExistsError("outputs/path_a_protocol_latency_20260904 is not empty")
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "latency_summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    env = environment()
    (OUT / "environment.json").write_text(json.dumps(env, indent=2), encoding="utf-8")
    contract = {
        "run_id": "path_a_protocol_latency_20260904",
        "research_type": "post hoc nonclinical local software-engineering latency assay",
        "research_question": "What latency is observed for direct and local MCP stdio calls, session initialization, and recovery in this implementation?",
        "hypotheses": {"null": "warm direct and MCP latency distributions do not differ", "alternative": "they differ"},
        "hypothesis_testing": "not performed; descriptive distributions only",
        "command": run_command(),
        "conditions": {
            "transport": "local stdio",
            "network_used": False,
            "concurrency": 1,
            "execution_order": "serial",
            "model_inference_included": False,
            "background_load_controlled": False,
        },
        "payload": {
            "source": "public synthetic clean control aligned with the existing Path A test fixture",
            "written_to_output": False,
            "definition_location": "scripts/run_path_a_protocol_latency.py",
        },
        "repetitions": {"warmup_cycles": WARMUP, "warm_per_operation": WARM_N, "cold_initialize": COLD_N, "recovery": RECOVERY_N},
        "definitions": {
            "percentiles": "linear interpolation on sorted observations",
            "interruption": "faulting review-call start through propagated exception return after interrupted-session cleanup",
            "recovery": "new-session start through successful initialize, context call, and review call",
            "total": "interruption measurement plus recovery measurement",
        },
        "files_hashed": {
            "scripts/run_path_a_protocol_latency.py": file_hash(ROOT / "scripts" / "run_path_a_protocol_latency.py"),
            "mcp_server.py": file_hash(SERVER),
            "prescription_mcp/orchestrator.py": file_hash(ROOT / "prescription_mcp" / "orchestrator.py"),
            "tests/faulty_mcp_server.py": file_hash(FAULT_SERVER),
        },
    }
    (OUT / "RUN_CONTRACT.json").write_text(json.dumps(contract, indent=2), encoding="utf-8")
    result = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS",
        "aggregate_only": True,
        "latency_rows": rows,
        "interruption_exception_type_counts": dict(exceptions),
        "validation": {
            "direct_mcp_context_equal": True,
            "direct_mcp_decision_equal": True,
            "all_required_metrics_finite": True,
            "successful_recovery_cycles": RECOVERY_N,
        },
        "claim_boundary": "One-machine local nonclinical stdio engineering measurements; no deployment, network, concurrency, clinical-workflow, safety, or patient-outcome inference.",
    }
    (OUT / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    keyed = {(row["condition"], row["operation"]): row for row in rows}
    labels = [
        ("Warm direct context", "warm_direct_reused_object", "get_lab_review_context"),
        ("Warm MCP context", "warm_mcp_reused_session", "get_lab_review_context"),
        ("Warm direct review", "warm_direct_reused_object", "review_prescription"),
        ("Warm MCP review", "warm_mcp_reused_session", "review_prescription"),
        ("Cold new-session initialization", "cold_mcp_new_session", "initialize"),
        ("New-session recovery after server exit", "post_interruption_new_session", "initialize_context_review_to_first_success"),
    ]
    lines = ["# Path A protocol latency assay", "", "Aggregate-only local, post hoc, nonclinical stdio results. No restricted record, identifier, network transport, concurrent request, or model inference was used.", ""]
    for label, condition, operation in labels:
        row = keyed[(condition, operation)]
        lines.append(f"- {label}: n={row['n']}, median {row['median_ms']:.3f} ms, Q1-Q3 {row['q1_ms']:.3f}-{row['q3_ms']:.3f} ms, IQR {row['iqr_ms']:.3f} ms, P95 {row['p95_ms']:.3f} ms.")
    lines += ["", f"Run with `{run_command()}`.", "", "Boundary: one machine and local stdio only; no inference about deployment, network, concurrency, pharmacist workflow, clinical latency, or safety."]
    (OUT / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


async def main():
    item = payload()
    direct_context_ms, direct_review_ms, direct_context, direct_review = measure_direct(item)
    mcp_context_ms, mcp_review_ms, mcp_context, mcp_review = await measure_warm_mcp(item)
    if direct_context != mcp_context or signature(direct_review) != signature(mcp_review):
        raise RuntimeError("direct and MCP results differ")
    cold_ms = await measure_cold_initialization()
    fault_ms, recovery_ms, total_ms, exceptions = await measure_recovery(item)
    rows = [
        summary_row("warm_direct_reused_object", "get_lab_review_context", direct_context_ms),
        summary_row("warm_mcp_reused_session", "get_lab_review_context", mcp_context_ms),
        summary_row("warm_direct_reused_object", "review_prescription", direct_review_ms),
        summary_row("warm_mcp_reused_session", "review_prescription", mcp_review_ms),
        summary_row("cold_mcp_new_session", "initialize", cold_ms),
        summary_row("server_interruption", "fault_call_to_exception_return", fault_ms),
        summary_row("post_interruption_new_session", "initialize_context_review_to_first_success", recovery_ms),
        summary_row("server_interruption", "fault_call_to_recovered_success", total_ms),
    ]
    write_results(rows, exceptions)


if __name__ == "__main__":
    asyncio.run(main())
