from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyBboxPatch


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "outputs/lab_evidence_benchmark_v2"
PATH_A = ROOT / "outputs/path_a_reanalysis_20260904"
OUT = ROOT / "outputs/lab_evidence_figures_v2"
SUMMARY = json.loads((DATA / "lab_evidence_benchmark_summary.json").read_text(encoding="utf-8"))
with (PATH_A / "clean_empirical_endpoints.csv").open(encoding="utf-8-sig", newline="") as handle:
    CLEAN_ROWS = list(csv.DictReader(handle))
with (PATH_A / "stratified_metrics.csv").open(encoding="utf-8-sig", newline="") as handle:
    STRATIFIED_ROWS = list(csv.DictReader(handle))

MODELS = ["qwen2.5-3b", "smollm2-1.7b", "phi3.5-mini"]
MODEL_LABELS = ["Qwen2.5-3B", "SmolLM2-1.7B", "Phi-3.5-mini"]
METHODS = ["mcp_access_only", "confidence_abstention", "mcp_governed"]
METHOD_LABELS = ["Evidence access", "Score-threshold abstention", "Contract-governed via MCP"]
COLORS = ["#D9826A", "#6F7F9A", "#287C76"]
HATCHES = ["///", "\\\\", "xx"]


def style() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9,
            "axes.labelsize": 9.5,
            "axes.titlesize": 10.5,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.linewidth": 0.8,
            "xtick.direction": "out",
            "ytick.direction": "out",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def save(fig, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"{name}.png", dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / f"{name}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def authority_map() -> None:
    fig, ax = plt.subplots(figsize=(9.6, 3.8))
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 7)
    ax.axis("off")
    columns = [
        (
            0.1,
            "Evidence state",
            [
                ("Traceable", "value, unit, time, source\nand encounter retained"),
                ("Detectably invalid", "missing, stale, wrong unit,\nconflict, mismatch, or service flag"),
                ("Silently substituted", "plausible value with no\nobservable provenance defect"),
            ],
        ),
        (
            4.25,
            "Evidence responsibility",
            [
                ("MCP evidence transport", "preserves state transitions\nand provenance fields"),
                ("Deterministic contract", "rejects anomalous records\nand owns thresholds"),
                ("Model candidate", "scored for every case; used only\nwhen auto-pass remains eligible"),
            ],
        ),
        (
            8.4,
            "Decision authority",
            [
                ("Auto-pass eligible", "only after validity and\nthreshold checks pass"),
                ("Human review required", "model auto-pass cannot\noverride the contract"),
                ("Outside authority", "no visible provenance\nsignal to evaluate"),
            ],
        ),
    ]
    fills = ["#EEF3F2", "#F8ECE8", "#F1F2F4"]
    for x, title, items in columns:
        ax.text(x + 1.55, 6.55, title, ha="center", va="center", weight="bold", fontsize=10.5)
        for index, (head, body) in enumerate(items):
            y = 4.95 - index * 1.75
            box = FancyBboxPatch(
                (x, y),
                3.1,
                1.25,
                boxstyle="round,pad=0.02,rounding_size=0.05",
                facecolor=fills[index],
                edgecolor="#707780",
                linewidth=0.9,
            )
            ax.add_patch(box)
            ax.text(x + 0.16, y + 0.84, head, weight="bold", fontsize=9.1, va="center")
            ax.text(x + 0.16, y + 0.39, body, fontsize=7.7, va="center", color="#33373C", linespacing=1.1)
    for y in [5.58, 3.83, 2.08]:
        ax.annotate("", xy=(4.08, y), xytext=(3.38, y), arrowprops=dict(arrowstyle="->", color="#6B7076", lw=1.2))
        ax.annotate("", xy=(8.23, y), xytext=(7.53, y), arrowprops=dict(arrowstyle="->", color="#6B7076", lw=1.2))
    ax.text(
        6,
        0.16,
        "The application-layer contract constrains auto-pass authority; MCP transport does not create that effect.",
        ha="center",
        color="#287C76",
        weight="bold",
        fontsize=9.2,
    )
    save(fig, "Fig1_lab_evidence_authority")


def metric_lookup(section: str = "overall") -> dict[tuple[str, str], dict]:
    return {(row["model"], row["method"]): row for row in SUMMARY[section]}


def exact_rate(row: dict, key: str) -> float:
    if key == "unsafe_approval":
        denominator = row["tp"] + row["fn"]
        return row["fn"] / denominator if denominator else 0.0
    if key == "unnecessary_escalation":
        denominator = row["tn"] + row["fp"]
        return row["fp"] / denominator if denominator else 0.0
    return row[key]


def interval_errors(row: dict, key: str) -> tuple[float, float]:
    value = 100 * exact_rate(row, key)
    low, high = row[f"{key}_domain_bootstrap_95ci"]
    return value - 100 * low, 100 * high - value


def clean_rate(row: dict, key: str) -> float:
    return float(row[key])


def clean_interval_errors(row: dict, key: str) -> tuple[float, float]:
    value = 100 * clean_rate(row, key)
    interval_key = key.replace("_rate", "") + "_domain_bootstrap_95ci"
    low, high = json.loads(row[interval_key])
    return value - 100 * low, 100 * high - value


def main_outcomes() -> None:
    lookup = {(row["model"], row["method"]): row for row in CLEAN_ROWS}
    rule_row = next(row for row in STRATIFIED_ROWS if row["method"] == "deterministic_rules" and row["stratum"] == "clean")
    x = np.arange(len(MODELS))
    width = 0.23
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.5), sharex=True)
    specs = [
        ("reference_discordant_auto_pass_rate", "Reference-discordant auto-pass (%)", 5.5),
        ("unnecessary_review_rate", "Unnecessary review among pass references (%)", 108),
    ]
    for ax, (metric, ylabel, ymax) in zip(axes, specs):
        for offset, method, label, color, hatch in zip([-width, 0, width], METHODS, METHOD_LABELS, COLORS, HATCHES):
            row_method = "score_threshold_abstention" if method == "confidence_abstention" else method
            rows = [lookup[(model, row_method)] for model in MODELS]
            values = np.array([100 * clean_rate(row, metric) for row in rows])
            errors = np.array([clean_interval_errors(row, metric) for row in rows]).T
            bars = ax.bar(
                x + offset,
                values,
                width,
                color=color,
                edgecolor="#4B5055",
                linewidth=0.65,
                hatch=hatch,
                yerr=errors,
                capsize=2.5,
                label=label,
            )
            for bar, value in zip(bars, values):
                inside = value > 96
                y = value - ymax * 0.055 if inside else value + ymax * 0.025
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    y,
                    f"{value:.1f}",
                    ha="center",
                    va="top" if inside else "baseline",
                    fontsize=7.4,
                    color="white" if inside else "black",
                    weight="bold" if inside else "normal",
                    rotation=90 if inside else 0,
                )
        rule = 100 * float(rule_row[metric])
        ax.axhline(rule, color="#6D737A", linestyle="--", linewidth=1.1)
        if rule > 0:
            ax.text(2.36, rule + ymax * 0.018, f"Rule baseline {rule:.1f}%", ha="right", color="#555B62", fontsize=7.6)
        ax.set_xticks(x, MODEL_LABELS)
        ax.set_ylabel(ylabel)
        ax.set_ylim(0, ymax)
        ax.grid(axis="y", linestyle="--", linewidth=0.6, alpha=0.25)
    axes[0].set_title("Clean-record auto-pass discordance")
    axes[1].set_title("Clean-record review workload")
    handles, labels = axes[1].get_legend_handles_labels()
    fig.legend(handles, labels, frameon=False, fontsize=8, loc="lower center", bbox_to_anchor=(0.5, -0.06), ncol=3)
    fig.suptitle("Pharmacist-anchored clean-record outcomes (264 records)", y=1.03, fontsize=11)
    save(fig, "Fig2_multimodel_authority_ablation")


def detectable_faults() -> None:
    states = ["missing", "stale", "unit_error", "conflict", "wrong_encounter", "service_failure"]
    state_labels = ["Missing", "Stale", "Unit error", "Conflict", "Wrong encounter", "Declared service flag"]
    rows = {(row["model"], row["method"], row["state"]): row for row in SUMMARY["detectable_faults"]}
    columns = []
    labels = []
    for model, model_label in zip(MODELS, MODEL_LABELS):
        for method, short in [("mcp_access_only", "Access"), ("mcp_governed", "Governed")]:
            columns.append([100 * exact_rate(rows[(model, method, state)], "unsafe_approval") for state in states])
            labels.append(f"{model_label}\n{short}")
    matrix = np.array(columns).T
    cmap = LinearSegmentedColormap.from_list("risk", ["#EEF3F2", "#F0C2B6", "#A83E3A"])
    fig, ax = plt.subplots(figsize=(7.7, 3.7))
    image = ax.imshow(matrix, cmap=cmap, vmin=0, vmax=max(30, float(matrix.max())), aspect="auto")
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            ax.text(j, i, f"{matrix[i, j]:.1f}", ha="center", va="center", fontsize=8, color="white" if matrix[i, j] > 18 else "#202428")
    ax.set_xticks(range(len(labels)), labels)
    ax.set_yticks(range(len(states)), state_labels)
    ax.set_title("Reference-discordant auto-pass under observable evidence faults (44 cases per state)")
    fig.colorbar(image, ax=ax, fraction=0.025, pad=0.02, label="Reference-discordant auto-pass (%)")
    save(fig, "Fig3_detectable_faults")


def failure_boundary() -> None:
    observable = {
        (row["model"], row["method"]): row
        for row in STRATIFIED_ROWS
        if row["stratum"] == "observable_fault" and row["method"] in METHODS
    }
    boundary = metric_lookup("failure_boundary")
    fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.55), sharey=True)
    for ax, lookup, title in [(axes[0], observable, "Protocol-defined observable-fault suite"), (axes[1], boundary, "Unobservable provenance substitution")]:
        if title == "Protocol-defined observable-fault suite":
            matrix = np.array([[100 * float(lookup[(model, method)]["reference_discordant_auto_pass_rate"]) for method in METHODS] for model in MODELS])
        else:
            matrix = np.array([[100 * exact_rate(lookup[(model, method)], "unsafe_approval") for method in METHODS] for model in MODELS])
        image = ax.imshow(matrix, cmap="Reds", vmin=0, vmax=100, aspect="auto")
        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                ax.text(j, i, f"{matrix[i, j]:.1f}", ha="center", va="center", fontsize=9, color="white" if matrix[i, j] > 55 else "#202428")
        ax.set_xticks(range(len(METHODS)), ["Access", "Score threshold", "Governed"])
        ax.set_title(title)
    axes[0].set_yticks(range(len(MODELS)), MODEL_LABELS)
    axes[1].tick_params(axis="y", left=False, labelleft=False)
    fig.colorbar(image, ax=axes, fraction=0.025, pad=0.025, label="Reference-discordant auto-pass (%)")
    fig.suptitle("The contract can act only on provenance represented in its inputs", y=1.01, fontsize=11)
    save(fig, "Fig4_failure_boundary")


def domain_confusion() -> None:
    rows = {(row["model"], row["method"], row["domain"]): row for row in SUMMARY["per_domain_confusion"]}
    domains = sorted({row["domain"] for row in SUMMARY["per_domain_confusion"]})
    short = [name.replace(" carbonate", "").replace(" sodium", "") for name in domains]
    fig, axes = plt.subplots(1, 3, figsize=(9.7, 5.0), sharey=True)
    for ax, model, label in zip(axes, MODELS, MODEL_LABELS):
        matrix = np.array([[rows[(model, "mcp_governed", domain)][key] for key in ["tp", "tn", "fp", "fn"]] for domain in domains])
        image = ax.imshow(matrix, cmap="Blues", vmin=0, vmax=36, aspect="auto")
        for i in range(matrix.shape[0]):
            for j in range(4):
                ax.text(j, i, str(matrix[i, j]), ha="center", va="center", fontsize=7.5, color="white" if matrix[i, j] > 22 else "#202428")
        ax.set_xticks(range(4), ["TP", "TN", "FP", "FN"])
        ax.set_title(label)
    axes[0].set_yticks(range(len(domains)), short)
    fig.colorbar(image, ax=axes, fraction=0.018, pad=0.02, label="Case count")
    fig.suptitle("Domain-level confusion counts for contract-governed decisions delivered through MCP", y=0.99, fontsize=11)
    save(fig, "FigS2_domain_confusion")


def sensitivity_and_stability() -> None:
    curve = SUMMARY["confidence_threshold_curve"]
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.3))
    for model, label, color in zip(MODELS, MODEL_LABELS, ["#287C76", "#6F7F9A", "#D9826A"]):
        rows = sorted((row for row in curve if row["model"] == model), key=lambda row: row["threshold"])
        thresholds = [row["threshold"] for row in rows]
        axes[0].plot(thresholds, [100 * row["unsafe_approval"] for row in rows], marker="o", color=color, label=label)
        axes[1].plot(thresholds, [100 * row["unnecessary_escalation"] for row in rows], marker="o", color=color, label=label)
    axes[0].set(ylabel="Reference-discordant auto-pass (%)", xlabel="Score threshold", ylim=(-1, 12))
    axes[1].set(ylabel="Unnecessary review (%)", xlabel="Score threshold", ylim=(0, 105))
    stability = SUMMARY["stability"]
    x = np.arange(len(MODELS))
    batch_diff = [100 * stability[model]["batch1_repeat0"]["max_probability_difference"] for model in MODELS]
    repeat_diff = [100 * stability[model]["batch8_repeat2"]["max_probability_difference"] for model in MODELS]
    axes[2].bar(x - 0.17, repeat_diff, 0.34, color="#6F7F9A", label="Repeat, batch 8")
    axes[2].bar(x + 0.17, batch_diff, 0.34, color="#287C76", label="Batch 1 vs 8")
    axes[2].set_xticks(x, ["Qwen", "SmolLM2", "Phi"])
    axes[2].set_ylabel("Maximum normalized-score shift (points)")
    axes[2].set_title("All decision agreements = 100%")
    for ax in axes:
        ax.grid(axis="y", linestyle="--", linewidth=0.6, alpha=0.25)
    axes[0].legend(frameon=False, fontsize=7.2)
    axes[2].legend(frameon=False, fontsize=7.2)
    fig.suptitle("Score-threshold abstention sensitivity and repeated-inference stability", y=1.03, fontsize=11)
    save(fig, "FigS3_sensitivity_stability")


def protocol_comparison() -> None:
    latency = SUMMARY["protocol"]["latency_ms"]
    labels = ["Context\ndirect", "Context\nMCP", "Review\ndirect", "Review\nMCP"]
    medians = [latency["direct_context_median"], latency["mcp_context_median"], latency["direct_review_median"], latency["mcp_review_median"]]
    p95 = [latency["direct_context_p95"], latency["mcp_context_p95"], latency["direct_review_p95"], latency["mcp_review_p95"]]
    colors = ["#AAB0B6", "#287C76", "#AAB0B6", "#287C76"]
    fig, ax = plt.subplots(figsize=(5.8, 3.3))
    x = np.arange(4)
    bars = ax.bar(x, medians, color=colors, width=0.65)
    ax.scatter(x, p95, marker="_", s=300, color="#A83E3A", linewidth=1.8, label="95th percentile")
    for bar, value, upper in zip(bars, medians, p95):
        ax.text(bar.get_x() + bar.get_width() / 2, max(value, upper) + 0.08, f"Median {value:.3f}", ha="center", fontsize=8)
    ax.set_xticks(x, labels)
    ax.set_ylabel("Latency (ms, model inference excluded)")
    ax.set_ylim(0, 4.3)
    ax.grid(axis="y", linestyle="--", linewidth=0.6, alpha=0.25)
    ax.legend(frameon=False, loc="upper left")
    ax.set_title("Real MCP stdio and direct calls returned identical structured contexts and contract decisions\n(660/660 cases)")
    save(fig, "FigS4_protocol_comparison")


def data_flow() -> None:
    fig, ax = plt.subplots(figsize=(7.4, 8.8))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 12.4)
    ax.axis("off")
    stages = [
        (10.45, "1  Clinical export", "Restricted clinical source pool", "#F1F2F4"),
        (9.05, "2  Deidentification", "Completed before pharmacist review", "#F1F2F4"),
        (7.65, "3  Blinded reference review", "Five pharmacists; 1,540 source records", "#EEF3F2"),
        (
            5.85,
            "4  Restricted analysis construction",
            "Re-keying, standardization, mapping, and non-endpoint Synthea\ndisplay replacement (exact internal order not asserted)",
            "#F8ECE8",
        ),
        (
            4.05,
            "5  Eligibility and strata construction",
            "Selection plus fault and boundary transformations",
            "#EEF3F2",
        ),
        (2.65, "6  Frozen technical set", "660 records across constructed analytic strata", "#EEF3F2"),
        (1.25, "7  Formal scoring", "Model/path comparison under the frozen contract", "#E4EFED"),
    ]
    heights = [0.9, 0.9, 0.9, 1.3, 0.9, 0.9, 0.9]
    for index, ((y, head, body, fill), height) in enumerate(zip(stages, heights)):
        box = FancyBboxPatch(
            (1.05, y),
            7.9,
            height,
            boxstyle="round,pad=0.025,rounding_size=0.05",
            facecolor=fill,
            edgecolor="#5D646B",
            linewidth=0.9,
        )
        ax.add_patch(box)
        ax.text(1.35, y + height * 0.68, head, fontsize=9.2, weight="bold", va="center", color="#202428")
        ax.text(1.35, y + height * 0.30, body, fontsize=7.9, va="center", color="#353A3F", linespacing=1.18)
        if index < len(stages) - 1:
            next_y, _, _, _ = stages[index + 1]
            ax.annotate(
                "",
                xy=(5.0, next_y + heights[index + 1]),
                xytext=(5.0, y),
                arrowprops=dict(arrowstyle="->", color="#6B7076", lw=1.15),
            )
    note = FancyBboxPatch(
        (0.65, 0.08),
        8.7,
        0.82,
        boxstyle="round,pad=0.02,rounding_size=0.04",
        facecolor="#FFF8E8",
        edgecolor="#9B7A36",
        linewidth=0.8,
    )
    ax.add_patch(note)
    ax.text(
        5.0,
        0.49,
        "Evidence boundary: exact display-field timing requires author confirmation.\n"
        "Constructed strata are not one-to-one branches from each source record.",
        ha="center",
        va="center",
        fontsize=7.7,
        color="#5A4720",
        linespacing=1.15,
    )
    ax.set_title("Confirmed data flow and unresolved restricted-workflow detail", fontsize=11, pad=10)
    save(fig, "FigS1_data_flow")


def main() -> None:
    style()
    authority_map()
    main_outcomes()
    detectable_faults()
    failure_boundary()
    domain_confusion()
    sensitivity_and_stability()
    protocol_comparison()
    data_flow()
    print(f"wrote figures to {OUT}")


if __name__ == "__main__":
    main()
