from __future__ import annotations

import csv
import json
import math
import random
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "outputs" / "lab_evidence_benchmark_v2"
OUTPUT = ROOT / "outputs" / "path_a_reanalysis_20260904"
MODELS = ("qwen2.5-3b", "smollm2-1.7b", "phi3.5-mini")
METHODS = ("deterministic_rules", "mcp_access_only", "confidence_abstention", "mcp_governed")
SEED = 20260904
BOOTSTRAPS = 10_000


def read_rows(model: str) -> list[dict]:
    with (SOURCE / "models" / model / "predictions.csv").open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 2_640:
        raise RuntimeError(f"Unexpected row count for {model}: {len(rows)}")
    return rows


def stratum(row: dict) -> str:
    if row["state"] == "clean":
        return "clean"
    if row["state"] == "silent_plausible_substitution":
        return "silent_provenance_boundary"
    return "observable_fault"


def summarize(rows: list[dict]) -> dict:
    n = len(rows)
    review_reference = [row for row in rows if row["reference"] == "review required"]
    pass_reference = [row for row in rows if row["reference"] == "approved"]
    discordant = sum(row["prediction"] == "approved" for row in review_reference)
    unnecessary = sum(row["prediction"] == "review required" for row in pass_reference)
    correct = sum(row["prediction"] == row["reference"] for row in rows)
    by_domain = defaultdict(list)
    for row in rows:
        by_domain[row["domain"]].append(row)
    domain_metrics = [summarize_no_macro(values) for values in by_domain.values()]
    return {
        "n": n,
        "review_reference_n": len(review_reference),
        "pass_reference_n": len(pass_reference),
        "reference_discordant_auto_pass_n": discordant,
        "reference_discordant_auto_pass_rate": discordant / len(review_reference) if review_reference else None,
        "unnecessary_review_n": unnecessary,
        "unnecessary_review_rate": unnecessary / len(pass_reference) if pass_reference else None,
        "accuracy": correct / n if n else None,
        "domain_macro_discordant_auto_pass_rate": mean_available(
            item["reference_discordant_auto_pass_rate"] for item in domain_metrics
        ),
        "domain_macro_unnecessary_review_rate": mean_available(
            item["unnecessary_review_rate"] for item in domain_metrics
        ),
    }


def summarize_no_macro(rows: list[dict]) -> dict:
    review_reference = [row for row in rows if row["reference"] == "review required"]
    pass_reference = [row for row in rows if row["reference"] == "approved"]
    discordant = sum(row["prediction"] == "approved" for row in review_reference)
    unnecessary = sum(row["prediction"] == "review required" for row in pass_reference)
    return {
        "reference_discordant_auto_pass_rate": discordant / len(review_reference) if review_reference else None,
        "unnecessary_review_rate": unnecessary / len(pass_reference) if pass_reference else None,
    }


def mean_available(values) -> float | None:
    kept = [value for value in values if value is not None]
    return sum(kept) / len(kept) if kept else None


def percentile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] * (upper - position) + ordered[upper] * (position - lower)


def metric_rate(rows: list[dict], name: str) -> float | None:
    summary = summarize_no_macro(rows)
    return summary[name]


def domain_bootstrap_rate(rows: list[dict], metric_name: str, seed_label: str) -> dict:
    domains = sorted({row["domain"] for row in rows})
    by_domain = {domain: [row for row in rows if row["domain"] == domain] for domain in domains}
    point = metric_rate(rows, metric_name)
    rng = random.Random(SEED + sum(map(ord, metric_name + seed_label)))
    samples = []
    for _ in range(BOOTSTRAPS):
        sample = []
        for domain in rng.choices(domains, k=len(domains)):
            sample.extend(by_domain[domain])
        rate = metric_rate(sample, metric_name)
        if rate is not None:
            samples.append(rate)
    return {
        "rate": point,
        "domain_bootstrap_95ci": [percentile(samples, 0.025), percentile(samples, 0.975)],
        "bootstrap_repetitions": len(samples),
        "cluster_count": len(domains),
    }


def paired_domain_bootstrap(
    rows: list[dict], metric_name: str, treatment: str = "mcp_governed"
) -> dict:
    by_method = {
        method: {row["case_id"]: row for row in rows if row["method"] == method}
        for method in ("mcp_access_only", treatment)
    }
    if set(by_method["mcp_access_only"]) != set(by_method[treatment]):
        raise RuntimeError("Paired methods do not contain the same case ids")
    domains = sorted({row["domain"] for row in by_method["mcp_access_only"].values()})
    domain_ids = {
        domain: [case_id for case_id, row in by_method["mcp_access_only"].items() if row["domain"] == domain]
        for domain in domains
    }
    access_rows = list(by_method["mcp_access_only"].values())
    treatment_rows = list(by_method[treatment].values())
    point = metric_rate(treatment_rows, metric_name) - metric_rate(access_rows, metric_name)
    rng = random.Random(SEED + sum(map(ord, metric_name + treatment)))
    samples = []
    for _ in range(BOOTSTRAPS):
        sampled_domains = rng.choices(domains, k=len(domains))
        access_sample, treatment_sample = [], []
        for domain in sampled_domains:
            for case_id in domain_ids[domain]:
                access_sample.append(by_method["mcp_access_only"][case_id])
                treatment_sample.append(by_method[treatment][case_id])
        access_rate = metric_rate(access_sample, metric_name)
        treatment_rate = metric_rate(treatment_sample, metric_name)
        if access_rate is not None and treatment_rate is not None:
            samples.append(treatment_rate - access_rate)
    return {
        "comparison": f"{treatment}_minus_mcp_access_only",
        "risk_difference": point,
        "domain_bootstrap_95ci": [percentile(samples, 0.025), percentile(samples, 0.975)],
        "bootstrap_repetitions": len(samples),
        "cluster_count": len(domains),
    }


def baseline_rows(base: list[dict], prediction: str) -> list[dict]:
    return [{**row, "prediction": prediction} for row in base]


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    all_rows = {model: read_rows(model) for model in MODELS}
    reference_rows = [row for row in all_rows[MODELS[0]] if row["method"] == "mcp_access_only"]
    if len(reference_rows) != 660:
        raise RuntimeError("Expected 660 reference rows")

    strata = {
        "main": lambda row: row["state"] != "silent_plausible_substitution",
        "clean": lambda row: stratum(row) == "clean",
        "observable_fault": lambda row: stratum(row) == "observable_fault",
        "silent_provenance_boundary": lambda row: stratum(row) == "silent_provenance_boundary",
    }
    metric_rows = []
    for model, rows in all_rows.items():
        for method in METHODS:
            method_rows = [row for row in rows if row["method"] == method]
            for label, keep in strata.items():
                values = summarize([row for row in method_rows if keep(row)])
                metric_rows.append({"model": model, "method": method, "stratum": label, **values})

    baseline_summary = []
    for label, keep in strata.items():
        selected = [row for row in reference_rows if keep(row)]
        for name, prediction in (("always_review", "review required"), ("always_auto_pass", "approved")):
            baseline_summary.append({"baseline": name, "stratum": label, **summarize(baseline_rows(selected, prediction))})

    paired = []
    for model, rows in all_rows.items():
        main_rows = [row for row in rows if row["state"] != "silent_plausible_substitution"]
        for metric_name in ("reference_discordant_auto_pass_rate", "unnecessary_review_rate"):
            paired.append({"model": model, "metric": metric_name, **paired_domain_bootstrap(main_rows, metric_name)})

    clean_endpoints = []
    clean_paired = []
    observable_enforcement = []
    score_threshold = []
    reader_method = {
        "mcp_access_only": "mcp_access_only",
        "confidence_abstention": "score_threshold_abstention",
        "mcp_governed": "mcp_governed",
    }
    for model, rows in all_rows.items():
        clean_rows = [row for row in rows if stratum(row) == "clean"]
        main_rows = [row for row in rows if row["state"] != "silent_plausible_substitution"]
        fault_rows = [row for row in rows if stratum(row) == "observable_fault"]
        for method in ("mcp_access_only", "confidence_abstention", "mcp_governed"):
            method_clean = [row for row in clean_rows if row["method"] == method]
            summary = summarize(method_clean)
            discordant_ci = domain_bootstrap_rate(
                method_clean, "reference_discordant_auto_pass_rate", f"{model}:{method}:clean"
            )
            workload_ci = domain_bootstrap_rate(
                method_clean, "unnecessary_review_rate", f"{model}:{method}:clean"
            )
            clean_endpoints.append({
                "model": model,
                "method": reader_method[method],
                "review_reference_n": summary["review_reference_n"],
                "reference_discordant_auto_pass_n": summary["reference_discordant_auto_pass_n"],
                "reference_discordant_auto_pass_rate": discordant_ci["rate"],
                "reference_discordant_auto_pass_domain_bootstrap_95ci": discordant_ci["domain_bootstrap_95ci"],
                "pass_reference_n": summary["pass_reference_n"],
                "unnecessary_review_n": summary["unnecessary_review_n"],
                "unnecessary_review_rate": workload_ci["rate"],
                "unnecessary_review_domain_bootstrap_95ci": workload_ci["domain_bootstrap_95ci"],
                "bootstrap_repetitions": BOOTSTRAPS,
                "cluster_count": len({row["domain"] for row in method_clean}),
            })
        for treatment in ("confidence_abstention", "mcp_governed"):
            for metric_name in ("reference_discordant_auto_pass_rate", "unnecessary_review_rate"):
                paired_result = paired_domain_bootstrap(clean_rows, metric_name, treatment)
                paired_result["comparison"] = f"{reader_method[treatment]}_minus_mcp_access_only"
                clean_paired.append({
                    "model": model,
                    "treatment": reader_method[treatment],
                    "reference": "mcp_access_only",
                    "metric": metric_name,
                    **paired_result,
                })
        access = {row["case_id"]: row for row in fault_rows if row["method"] == "mcp_access_only"}
        governed = {row["case_id"]: row for row in fault_rows if row["method"] == "mcp_governed"}
        opportunities = [case_id for case_id, row in access.items() if row["prediction"] == "approved"]
        revoked = sum(governed[case_id]["prediction"] == "review required" for case_id in opportunities)
        observable_enforcement.append({
            "model": model,
            "observable_fault_n": len(access),
            "access_auto_pass_opportunities_n": len(opportunities),
            "revoked_by_contract_n": revoked,
            "conditional_enforcement_coverage": revoked / len(opportunities) if opportunities else None,
        })
        threshold_rows = [row for row in main_rows if row["method"] == "confidence_abstention"]
        threshold_summary = summarize(threshold_rows)
        threshold_discordant = domain_bootstrap_rate(
            threshold_rows, "reference_discordant_auto_pass_rate", f"{model}:threshold:main"
        )
        threshold_workload = domain_bootstrap_rate(
            threshold_rows, "unnecessary_review_rate", f"{model}:threshold:main"
        )
        score_threshold.append({
            "model": model,
            "threshold": 0.60,
            "review_reference_n": threshold_summary["review_reference_n"],
            "reference_discordant_auto_pass_n": threshold_summary["reference_discordant_auto_pass_n"],
            "reference_discordant_auto_pass_rate": threshold_discordant["rate"],
            "reference_discordant_auto_pass_domain_bootstrap_95ci": threshold_discordant["domain_bootstrap_95ci"],
            "pass_reference_n": threshold_summary["pass_reference_n"],
            "unnecessary_review_n": threshold_summary["unnecessary_review_n"],
            "unnecessary_review_rate": threshold_workload["rate"],
            "unnecessary_review_domain_bootstrap_95ci": threshold_workload["domain_bootstrap_95ci"],
            "bootstrap_repetitions": BOOTSTRAPS,
            "cluster_count": len({row["domain"] for row in threshold_rows}),
        })

    batch = []
    for model in MODELS:
        raw = json.loads((SOURCE / "models" / model / "raw_scores_and_stability.json").read_text(encoding="utf-8"))
        first = raw["stability"]["batch8_repeat0"]
        second = raw["stability"]["batch1_repeat0"]
        ids = sorted(first)
        shifts = [abs(first[case_id][1] - second[case_id][1]) for case_id in ids]
        candidate_flips = sum(first[case_id][0] != second[case_id][0] for case_id in ids)
        score_threshold_flips = sum(
            (first[case_id][1] > 0.4) != (second[case_id][1] > 0.4)
            for case_id in ids
        )
        batch.append({
            "model": model,
            "n": len(ids),
            "candidate_decision_flips": candidate_flips,
            "score_threshold_path_decision_flips_at_0_60": score_threshold_flips,
            "median_absolute_probability_shift": percentile(shifts, 0.5),
            "p95_absolute_probability_shift": percentile(shifts, 0.95),
            "maximum_absolute_probability_shift": max(shifts),
            "cases_with_shift_ge_0_05": sum(value >= 0.05 for value in shifts),
        })

    upper_zero_396 = 1 - 0.05 ** (1 / 396)
    result = {
        "scope": "Reanalysis of retained 28 July 2026 synthetic-surrogate result rows; not a rerun of the confidential clinical 660-record analysis.",
        "source_contract": json.loads((SOURCE / "RUN_CONTRACT.json").read_text(encoding="utf-8")),
        "stratum_counts": {
            label: summarize([row for row in reference_rows if keep(row)])
            for label, keep in strata.items()
        },
        "paired_risk_differences": paired,
        "clean_empirical_endpoints": clean_endpoints,
        "clean_paired_risk_differences": clean_paired,
        "observable_fault_enforcement": observable_enforcement,
        "score_threshold_abstention": score_threshold,
        "always_decision_baselines": baseline_summary,
        "batch_size_sensitivity": batch,
        "zero_of_396_one_sided_95pct_binomial_upper_bound": upper_zero_396,
        "statistical_boundary": (
            "Domain bootstrap intervals resample 11 drug domains and retain paired records. They describe this fixed technical set, "
            "not patient-level or population uncertainty. The zero-event binomial bound is descriptive only and ignores source-case dependence."
        ),
    }
    write_csv(OUTPUT / "stratified_metrics.csv", metric_rows)
    write_csv(OUTPUT / "always_decision_baselines.csv", baseline_summary)
    write_csv(OUTPUT / "paired_risk_differences.csv", paired)
    write_csv(OUTPUT / "clean_empirical_endpoints.csv", clean_endpoints)
    write_csv(OUTPUT / "clean_paired_risk_differences.csv", clean_paired)
    write_csv(OUTPUT / "observable_fault_enforcement.csv", observable_enforcement)
    write_csv(OUTPUT / "score_threshold_abstention.csv", score_threshold)
    write_csv(OUTPUT / "batch_size_sensitivity.csv", batch)
    (OUTPUT / "path_a_reanalysis.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUTPUT / "README.md").write_text(
        "# Path A existing-result reanalysis\n\n"
        "This directory contains aggregate-only reanalysis of the retained 28 July 2026 non-clinical synthetic surrogate. "
        "It adds always-review/always-auto-pass baselines, clean/observable-fault/silent-boundary strata, reference-separated endpoints, paired domain-bootstrap risk differences, a reader-facing score-threshold summary, and batch-size shift summaries. "
        "These outputs do not establish robustness of the confidential clinical 660-record analysis.\n",
        encoding="utf-8",
    )
    print(json.dumps({"output": str(OUTPUT), "paired": paired, "batch": batch}, indent=2))


if __name__ == "__main__":
    main()
