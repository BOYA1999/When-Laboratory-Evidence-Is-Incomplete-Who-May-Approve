from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import json
import math
import os
import platform
import random
import statistics
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "outputs/lab_evidence_benchmark_v2/prepared_mcp_contexts_660.jsonl"
OUTPUT = ROOT / "outputs/path_a_scoring_robustness_20260904"
SEED = 20260728
BATCH_SIZE = 8
MAX_LENGTH = 512
DATASET_LABEL = "2026-07-28 nonclinical synthetic surrogate"
MODELS = {
    "qwen2.5-3b": {
        "model_id": "Qwen/Qwen2.5-3B-Instruct",
        "revision": "aa8e72537993ba99e69dfaafa59ed015b17504d1",
    },
    "smollm2-1.7b": {
        "model_id": "HuggingFaceTB/SmolLM2-1.7B-Instruct",
        "revision": "31b70e2e869a7173562077fd711b654946d38674",
    },
    "phi3.5-mini": {
        "model_id": "microsoft/Phi-3.5-mini-instruct",
        "revision": "2fe192450127e6a83f7441aef6e3ca586c338b77",
    },
}
BASE_INSTRUCTION = (
    "Review this synthetic prescription using only the supplied public-label rule and structured evidence. "
    "Return exactly REVIEW_REQUIRED or APPROVED. You retain final decision authority."
)
CONDITIONS = {
    "original": {
        "instruction": BASE_INSTRUCTION,
        "labels": ["REVIEW_REQUIRED", "APPROVED"],
        "semantics": {"REVIEW_REQUIRED": "review required", "APPROVED": "approved"},
    },
    "reversed_candidate_order": {
        "instruction": BASE_INSTRUCTION,
        "labels": ["APPROVED", "REVIEW_REQUIRED"],
        "semantics": {"REVIEW_REQUIRED": "review required", "APPROVED": "approved"},
    },
    "ab_a_is_review": {
        "instruction": (
            "Review this synthetic prescription using only the supplied public-label rule and structured evidence. "
            "Return exactly A if pharmacist review is required or B if the record may be approved. "
            "You retain final decision authority."
        ),
        "labels": ["A", "B"],
        "semantics": {"A": "review required", "B": "approved"},
    },
    "ab_b_is_review": {
        "instruction": (
            "Review this synthetic prescription using only the supplied public-label rule and structured evidence. "
            "Return exactly B if pharmacist review is required or A if the record may be approved. "
            "You retain final decision authority."
        ),
        "labels": ["A", "B"],
        "semantics": {"A": "approved", "B": "review required"},
    },
    "review_approve": {
        "instruction": (
            "Review this synthetic prescription using only the supplied public-label rule and structured evidence. "
            "Return exactly REVIEW or APPROVE. You retain final decision authority."
        ),
        "labels": ["REVIEW", "APPROVE"],
        "semantics": {"REVIEW": "review required", "APPROVE": "approved"},
    },
    "refer_pass": {
        "instruction": (
            "Review this synthetic prescription using only the supplied public-label rule and structured evidence. "
            "Return exactly REFER or PASS. You retain final decision authority."
        ),
        "labels": ["REFER", "PASS"],
        "semantics": {"REFER": "review required", "PASS": "approved"},
    },
    "prompt_variant_1": {
        "instruction": (
            "Assess this synthetic prescription against only the supplied public-label rule and structured evidence. "
            "Choose REVIEW_REQUIRED when pharmacist review is required; otherwise choose APPROVED. "
            "Return one exact label without explanation. You retain final decision authority."
        ),
        "labels": ["REVIEW_REQUIRED", "APPROVED"],
        "semantics": {"REVIEW_REQUIRED": "review required", "APPROVED": "approved"},
    },
    "prompt_variant_2": {
        "instruction": (
            "Using only the public-label rule and structured evidence below, determine whether this synthetic "
            "prescription needs pharmacist review. Respond only with REVIEW_REQUIRED or APPROVED. "
            "You retain final decision authority."
        ),
        "labels": ["REVIEW_REQUIRED", "APPROVED"],
        "semantics": {"REVIEW_REQUIRED": "review required", "APPROVED": "approved"},
    },
}
CONTENT_FREE_BODIES = {
    "empty_objects": "Rules: {}\nEvidence: {}",
    "empty_schema": (
        'Rules: []\nEvidence: {"patient_context":{},"medications":[],"laboratory_evidence":[],"data_quality_notices":[]}'
    ),
    "no_information": "Rules: No rule information is provided.\nEvidence: No case information is provided.",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sigmoid(value: float) -> float:
    if value >= 0:
        return 1.0 / (1.0 + math.exp(-value))
    exp_value = math.exp(value)
    return exp_value / (1.0 + exp_value)


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    temp.replace(path)


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    temp.replace(path)


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def load_rows(scope: str) -> list[dict]:
    rows = read_jsonl(INPUT)
    if len(rows) != 660 or len({row["prompt_sha256"] for row in rows}) != 660:
        raise RuntimeError("The public surrogate input must contain 660 unique frozen prompts")
    if scope == "full660":
        return rows
    selected = []
    for domain in sorted({row["domain"] for row in rows}):
        domain_rows = [row for row in rows if row["domain"] == domain]
        clean = [row for row in domain_rows if row["state"] == "clean"]
        if scope == "screen132":
            selected.extend(clean[:8])
        else:
            selected.extend([row for row in clean if row["reference"] == "review required"][:4])
            selected.extend([row for row in clean if row["reference"] == "approved"][:4])
        for state in ("missing", "wrong_encounter", "service_failure", "silent_plausible_substitution"):
            selected.append(next(row for row in domain_rows if row["state"] == state))
    if len(selected) != 132:
        raise RuntimeError(f"Expected 132 screening cases, found {len(selected)}")
    if scope == "stratified132":
        references = Counter(row["reference"] for row in selected)
        if references != {"review required": 88, "approved": 44}:
            raise RuntimeError(f"Unexpected stratified reference counts: {references}")
    return selected


def prompt_body(prompt: str) -> str:
    marker = "\nRules:"
    if marker not in prompt:
        raise ValueError("Frozen prompt does not contain the Rules marker")
    return prompt[prompt.index(marker) + 1 :]


def condition_prompt(row: dict, condition: dict) -> str:
    if condition["instruction"] == BASE_INSTRUCTION:
        return row["prompt"]
    return condition["instruction"] + "\n" + prompt_body(row["prompt"])


class Scorer:
    def __init__(self, alias: str) -> None:
        import torch
        import transformers
        from transformers import AutoModelForCausalLM, AutoTokenizer

        spec = MODELS[alias]
        random.seed(SEED)
        torch.manual_seed(SEED)
        torch.cuda.manual_seed_all(SEED)
        torch.use_deterministic_algorithms(True, warn_only=True)
        self.alias = alias
        self.torch = torch
        self.transformers_version = transformers.__version__
        self.tokenizer = AutoTokenizer.from_pretrained(
            spec["model_id"], revision=spec["revision"], local_files_only=True,
            padding_side="left", trust_remote_code=True,
        )
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.truncation_side = "left"
        load_args = {
            "revision": spec["revision"], "local_files_only": True, "dtype": torch.bfloat16,
            "device_map": "cuda", "attn_implementation": "sdpa", "trust_remote_code": True,
        }
        try:
            self.model = AutoModelForCausalLM.from_pretrained(spec["model_id"], **load_args).eval()
        except (TypeError, ValueError):
            load_args.pop("attn_implementation")
            self.model = AutoModelForCausalLM.from_pretrained(spec["model_id"], **load_args).eval()
        self.environment = {
            "model_alias": alias,
            "model_id": spec["model_id"],
            "snapshot_revision": spec["revision"],
            "parameters": self.model.num_parameters(),
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "torch": torch.__version__,
            "transformers": self.transformers_version,
            "cuda_runtime": torch.version.cuda,
            "device": torch.cuda.get_device_name(0),
            "device_memory_bytes": torch.cuda.get_device_properties(0).total_memory,
            "model_forward_dtype": "bfloat16",
            "score_normalization_dtype": "float32",
            "full_model_fp32_run": False,
            "full_model_fp32_reason": "Not attempted: the 12-GB GPU cannot hold all study models in FP32 with inference activations.",
        }

    def prefix(self, prompt: str) -> str:
        if getattr(self.tokenizer, "chat_template", None):
            return self.tokenizer.apply_chat_template(
                [{"role": "user", "content": prompt}], tokenize=False, add_generation_prompt=True
            )
        return f"User: {prompt}\nAssistant:"

    def score(self, prompts: list[str], labels: list[str], progress: str) -> list[dict]:
        prefixes = [self.prefix(prompt) for prompt in prompts]
        candidates = [(index, prefix, label) for index, prefix in enumerate(prefixes) for label in labels]
        results = [None] * len(candidates)
        batch_count = math.ceil(len(candidates) / BATCH_SIZE)
        started = time.perf_counter()
        for batch_index, start in enumerate(range(0, len(candidates), BATCH_SIZE), start=1):
            batch = candidates[start : start + BATCH_SIZE]
            metadata = []
            texts = []
            for prompt_index, prefix, label in batch:
                prefix_ids = self.tokenizer(prefix, add_special_tokens=False)["input_ids"]
                full_ids = self.tokenizer(prefix + label, add_special_tokens=False)["input_ids"]
                candidate_length = len(full_ids) - len(prefix_ids)
                common = 0
                for first, second in zip(prefix_ids, full_ids):
                    if first != second:
                        break
                    common += 1
                if candidate_length < 1 or candidate_length > MAX_LENGTH:
                    raise RuntimeError(f"Invalid candidate length for {label}: {candidate_length}")
                texts.append(prefix + label)
                metadata.append({
                    "prompt_index": prompt_index,
                    "label": label,
                    "prefix_token_count": len(prefix_ids),
                    "full_token_count_before_truncation": len(full_ids),
                    "truncated_prefix_token_count": max(0, len(full_ids) - MAX_LENGTH),
                    "prefix_boundary_changed_token_count": len(prefix_ids) - common,
                    "candidate_token_count": candidate_length,
                    "candidate_token_ids": full_ids[-candidate_length:],
                    "candidate_tokens": self.tokenizer.convert_ids_to_tokens(full_ids[-candidate_length:]),
                })
            encoded = self.tokenizer(
                texts, return_tensors="pt", padding=True, truncation=True,
                max_length=MAX_LENGTH, add_special_tokens=False,
            ).to(self.model.device)
            with self.torch.inference_mode():
                logits = self.model(**encoded, use_cache=False).logits.float().log_softmax(dim=-1)
            width = encoded["input_ids"].shape[1]
            for row_index, meta in enumerate(metadata):
                length = meta["candidate_token_count"]
                token_scores = [
                    logits[row_index, position - 1, encoded["input_ids"][row_index, position]].item()
                    for position in range(width - length, width)
                ]
                meta["candidate_mean_log_likelihood"] = sum(token_scores) / len(token_scores)
                results[start + row_index] = meta
            del logits, encoded
            if batch_index == 1 or batch_index % 25 == 0 or batch_index == batch_count:
                elapsed = time.perf_counter() - started
                print(
                    f"PROGRESS model={self.alias} condition={progress} batch={batch_index}/{batch_count} "
                    f"elapsed_seconds={elapsed:.1f}", flush=True,
                )
        grouped = [[] for _ in prompts]
        for result in results:
            grouped[result["prompt_index"]].append({key: value for key, value in result.items() if key != "prompt_index"})
        return grouped


def semantic_scores(candidate_rows: list[dict], semantics: dict[str, str]) -> tuple[float, float]:
    by_semantic = {
        semantics[row["label"]]: row["candidate_mean_log_likelihood"] for row in candidate_rows
    }
    return by_semantic["review required"], by_semantic["approved"]


def case_output(
    scope: str, alias: str, condition_name: str, condition: dict, row: dict, prompt: str,
    candidates: list[dict], bias: float, score_source: str,
) -> dict:
    review_score, approve_score = semantic_scores(candidates, condition["semantics"])
    raw_log_odds = review_score - approve_score
    calibrated_log_odds = raw_log_odds - bias
    return {
        "dataset": DATASET_LABEL,
        "scope": scope,
        "model": alias,
        "model_id": MODELS[alias]["model_id"],
        "snapshot_revision": MODELS[alias]["revision"],
        "condition": condition_name,
        "case_id": row["case_id"],
        "domain": row["domain"],
        "state": row["state"],
        "reference": row["reference"],
        "source_prompt_sha256": row["prompt_sha256"],
        "condition_prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
        "labels_in_scoring_order": condition["labels"],
        "semantic_mapping": condition["semantics"],
        "candidate_scores": candidates,
        "review_score": review_score,
        "approve_score": approve_score,
        "raw_review_minus_approve": raw_log_odds,
        "raw_review_probability": sigmoid(raw_log_odds),
        "raw_prediction": "review required" if raw_log_odds >= 0 else "approved",
        "content_free_bias_review_minus_approve": bias,
        "calibrated_review_minus_approve": calibrated_log_odds,
        "calibrated_review_probability": sigmoid(calibrated_log_odds),
        "calibrated_prediction": "review required" if calibrated_log_odds >= 0 else "approved",
        "any_truncation": any(item["truncated_prefix_token_count"] > 0 for item in candidates),
        "any_prefix_boundary_change": any(item["prefix_boundary_changed_token_count"] > 0 for item in candidates),
        "score_source": score_source,
    }


def score_model(scope: str, alias: str) -> None:
    rows = load_rows(scope)
    local = OUTPUT / scope / "local_only_DO_NOT_PACKAGE"
    local.mkdir(parents=True, exist_ok=True)
    scorer = Scorer(alias)
    write_json(local / f"{alias}__environment.json", {
        **scorer.environment,
        "dataset": DATASET_LABEL,
        "input_path": str(INPUT),
        "input_sha256": sha256(INPUT),
        "script_sha256": sha256(Path(__file__)),
        "scope": scope,
        "case_count": len(rows),
        "reused_case_count_per_condition": 88 if scope == "stratified132" else 0,
        "new_inference_case_count_per_condition": 44 if scope == "stratified132" else len(rows),
        "command": " ".join(sys.argv),
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
    })
    for condition_name, condition in CONDITIONS.items():
        raw_path = local / f"{alias}__{condition_name}.jsonl"
        bias_path = local / f"{alias}__{condition_name}__content_free.json"
        if raw_path.exists() and bias_path.exists():
            print(f"SKIP model={alias} condition={condition_name} reason=existing", flush=True)
            continue
        reused = {}
        if scope == "stratified132":
            screen_local = OUTPUT / "screen132/local_only_DO_NOT_PACKAGE"
            screen_raw_path = screen_local / f"{alias}__{condition_name}.jsonl"
            screen_bias_path = screen_local / f"{alias}__{condition_name}__content_free.json"
            if not screen_raw_path.exists() or not screen_bias_path.exists():
                raise FileNotFoundError("Complete screen132 before stratified132 reuse")
            screen_bias = json.loads(screen_bias_path.read_text(encoding="utf-8"))
            if screen_bias["model"] != alias or screen_bias["condition"] != condition_name:
                raise RuntimeError("Content-free reuse identity mismatch")
            bias = screen_bias["content_free_bias_review_minus_approve"]
            write_json(bias_path, {
                **screen_bias,
                "reused_from": f"screen132/local_only_DO_NOT_PACKAGE/{screen_bias_path.name}",
            })
            target_by_id = {row["case_id"]: row for row in rows}
            for prior in read_jsonl(screen_raw_path):
                if prior["case_id"] not in target_by_id:
                    continue
                target = target_by_id[prior["case_id"]]
                expected_prompt = condition_prompt(target, condition)
                checks = (
                    prior["source_prompt_sha256"] == target["prompt_sha256"],
                    prior["condition_prompt_sha256"] == hashlib.sha256(expected_prompt.encode("utf-8")).hexdigest(),
                    prior["labels_in_scoring_order"] == condition["labels"],
                    prior["semantic_mapping"] == condition["semantics"],
                    prior["snapshot_revision"] == MODELS[alias]["revision"],
                    prior["domain"] == target["domain"],
                    prior["state"] == target["state"],
                    prior["reference"] == target["reference"],
                )
                if not all(checks):
                    raise RuntimeError(f"Reuse hash or identity mismatch for {prior['case_id']}")
                copied = dict(prior)
                copied["scope"] = scope
                copied["score_source"] = "reused_from_screen132_after_hash_verification"
                reused[prior["case_id"]] = copied
            if len(reused) != 88:
                raise RuntimeError(f"Expected 88 verified reusable cases, found {len(reused)}")
        else:
            anchor_ids = list(CONTENT_FREE_BODIES)
            anchor_prompts = [condition["instruction"] + "\n" + CONTENT_FREE_BODIES[key] for key in anchor_ids]
            anchor_candidates = scorer.score(anchor_prompts, condition["labels"], f"{condition_name}:content_free")
            anchors = []
            for anchor_id, candidates in zip(anchor_ids, anchor_candidates):
                review_score, approve_score = semantic_scores(candidates, condition["semantics"])
                anchors.append({
                    "anchor": anchor_id,
                    "candidate_scores": candidates,
                    "review_minus_approve": review_score - approve_score,
                })
            bias = statistics.mean(row["review_minus_approve"] for row in anchors)
            write_json(bias_path, {
                "dataset": DATASET_LABEL,
                "model": alias,
                "condition": condition_name,
                "content_free_bias_review_minus_approve": bias,
                "anchors": anchors,
            })
        inference_rows = [row for row in rows if row["case_id"] not in reused]
        prompts = [condition_prompt(row, condition) for row in inference_rows]
        scored = scorer.score(prompts, condition["labels"], condition_name)
        inferred = {
            row["case_id"]: case_output(
                scope, alias, condition_name, condition, row, prompt, candidates, bias, "new_inference"
            )
            for row, prompt, candidates in zip(inference_rows, prompts, scored)
        }
        output_rows = [reused.get(row["case_id"], inferred.get(row["case_id"])) for row in rows]
        if any(row is None for row in output_rows):
            raise RuntimeError("Merged stratified output is incomplete")
        write_jsonl(raw_path, output_rows)
        print(
            f"DONE model={alias} condition={condition_name} cases={len(output_rows)} "
            f"reused={len(reused)} inferred={len(inferred)} bias={bias:.6f}", flush=True,
        )
    del scorer.model
    gc.collect()
    scorer.torch.cuda.empty_cache()


def metric_summary(rows: list[dict], prediction_key: str) -> dict:
    tp = sum(row["reference"] == "review required" and row[prediction_key] == "review required" for row in rows)
    tn = sum(row["reference"] == "approved" and row[prediction_key] == "approved" for row in rows)
    fp = sum(row["reference"] == "approved" and row[prediction_key] == "review required" for row in rows)
    fn = sum(row["reference"] == "review required" and row[prediction_key] == "approved" for row in rows)
    return {
        "tp": tp, "tn": tn, "fp": fp, "fn": fn,
        "accuracy": (tp + tn) / len(rows),
        "reference_discordant_approval": fn / (tp + fn) if tp + fn else "NA",
        "unnecessary_escalation": fp / (tn + fp) if tn + fp else "NA",
    }


def mode(values: list[int]) -> int:
    counts = Counter(values)
    return min(key for key, count in counts.items() if count == max(counts.values()))


def total_likelihood_prediction(row: dict) -> str:
    semantics = CONDITIONS[row["condition"]]["semantics"]
    totals = {
        semantics[item["label"]]: item["candidate_mean_log_likelihood"] * item["candidate_token_count"]
        for item in row["candidate_scores"]
    }
    return "review required" if totals["review required"] >= totals["approved"] else "approved"


def summarize(scope: str) -> None:
    source_rows = load_rows(scope)
    local = OUTPUT / scope / "local_only_DO_NOT_PACKAGE"
    aggregate = OUTPUT / scope / "aggregate_for_submission"
    condition_rows = []
    agreement_rows = []
    token_rows = []
    bias_rows = []
    reproduction_rows = []
    mean_total_rows = []
    calibration_effect_rows = []
    reuse_audit_rows = []
    raw_by_model_condition = {}
    for alias in MODELS:
        for condition_name in CONDITIONS:
            path = local / f"{alias}__{condition_name}.jsonl"
            bias_path = local / f"{alias}__{condition_name}__content_free.json"
            if not path.exists() or not bias_path.exists():
                raise FileNotFoundError(f"Missing completed output: {path}")
            rows = read_jsonl(path)
            if len(rows) != len(source_rows):
                raise RuntimeError(f"Unexpected row count in {path}: {len(rows)}")
            raw_by_model_condition[(alias, condition_name)] = rows
            if scope == "stratified132":
                screen_path = OUTPUT / f"screen132/local_only_DO_NOT_PACKAGE/{alias}__{condition_name}.jsonl"
                screen_by_id = {row["case_id"]: row for row in read_jsonl(screen_path)}
                reused_rows = [row for row in rows if row.get("score_source", "").startswith("reused")]
                new_rows = [row for row in rows if row.get("score_source") == "new_inference"]
                screen_bias = json.loads(
                    (OUTPUT / f"screen132/local_only_DO_NOT_PACKAGE/{alias}__{condition_name}__content_free.json")
                    .read_text(encoding="utf-8")
                )
                stratified_bias = json.loads(bias_path.read_text(encoding="utf-8"))
                reuse_audit_rows.append({
                    "dataset": DATASET_LABEL, "scope": scope, "model": alias, "condition": condition_name,
                    "merged_n": len(rows), "merged_unique_case_n": len({row["case_id"] for row in rows}),
                    "reused_case_n": len(reused_rows), "new_inference_case_n": len(new_rows),
                    "source_input_consistency_n": sum(
                        row["source_prompt_sha256"] == screen_by_id[row["case_id"]]["source_prompt_sha256"]
                        for row in reused_rows
                    ),
                    "condition_input_consistency_n": sum(
                        row["condition_prompt_sha256"] == screen_by_id[row["case_id"]]["condition_prompt_sha256"]
                        for row in reused_rows
                    ),
                    "candidate_scores_exact_match_n": sum(
                        row["candidate_scores"] == screen_by_id[row["case_id"]]["candidate_scores"]
                        for row in reused_rows
                    ),
                    "identity_fields_match_n": sum(
                        all(row[key] == screen_by_id[row["case_id"]][key] for key in (
                            "model", "model_id", "snapshot_revision", "condition", "domain", "state", "reference",
                            "labels_in_scoring_order", "semantic_mapping",
                        )) for row in reused_rows
                    ),
                    "content_free_bias_exact_match": (
                        stratified_bias["content_free_bias_review_minus_approve"]
                        == screen_bias["content_free_bias_review_minus_approve"]
                    ),
                    "content_free_anchors_exact_match": stratified_bias["anchors"] == screen_bias["anchors"],
                })
            raw_metrics = metric_summary(rows, "raw_prediction")
            calibrated_metrics = metric_summary(rows, "calibrated_prediction")
            raw_calibrated_agreement = sum(
                row["raw_prediction"] == row["calibrated_prediction"] for row in rows
            )
            condition_rows.append({
                "dataset": DATASET_LABEL, "scope": scope, "model": alias, "condition": condition_name,
                "n": len(rows), "reference_review_required_n": sum(r["reference"] == "review required" for r in rows),
                "reference_approved_n": sum(r["reference"] == "approved" for r in rows),
                "raw_review_n": sum(r["raw_prediction"] == "review required" for r in rows),
                "raw_accuracy": raw_metrics["accuracy"],
                "raw_reference_discordant_approval": raw_metrics["reference_discordant_approval"],
                "raw_unnecessary_escalation": raw_metrics["unnecessary_escalation"],
                "calibrated_review_n": sum(r["calibrated_prediction"] == "review required" for r in rows),
                "calibrated_accuracy": calibrated_metrics["accuracy"],
                "calibrated_reference_discordant_approval": calibrated_metrics["reference_discordant_approval"],
                "calibrated_unnecessary_escalation": calibrated_metrics["unnecessary_escalation"],
                "truncated_case_n": sum(r["any_truncation"] for r in rows),
                "prefix_boundary_change_case_n": sum(r["any_prefix_boundary_change"] for r in rows),
                "reused_case_n": sum(r.get("score_source", "new_inference").startswith("reused") for r in rows),
                "new_inference_case_n": sum(not r.get("score_source", "new_inference").startswith("reused") for r in rows),
            })
            calibration_effect_rows.append({
                "dataset": DATASET_LABEL, "scope": scope, "model": alias, "condition": condition_name,
                "n": len(rows), "content_free_bias_review_minus_approve": rows[0]["content_free_bias_review_minus_approve"],
                "raw_review_n": sum(row["raw_prediction"] == "review required" for row in rows),
                "calibrated_review_n": sum(row["calibrated_prediction"] == "review required" for row in rows),
                "raw_vs_calibrated_agreement": raw_calibrated_agreement / len(rows),
                "raw_vs_calibrated_flip_n": len(rows) - raw_calibrated_agreement,
                "calibration_flip_to_review_n": sum(
                    row["raw_prediction"] == "approved" and row["calibrated_prediction"] == "review required"
                    for row in rows
                ),
                "calibration_flip_to_approve_n": sum(
                    row["raw_prediction"] == "review required" and row["calibrated_prediction"] == "approved"
                    for row in rows
                ),
            })
            total_rows = [{**row, "total_prediction": total_likelihood_prediction(row)} for row in rows]
            total_metrics = metric_summary(total_rows, "total_prediction")
            mean_total_agreement = sum(row["raw_prediction"] == row["total_prediction"] for row in total_rows)
            mean_total_rows.append({
                "dataset": DATASET_LABEL, "scope": scope, "model": alias, "condition": condition_name,
                "n": len(rows), "mean_review_n": sum(row["raw_prediction"] == "review required" for row in total_rows),
                "total_review_n": sum(row["total_prediction"] == "review required" for row in total_rows),
                "mean_vs_total_agreement": mean_total_agreement / len(rows),
                "mean_vs_total_flip_n": len(rows) - mean_total_agreement,
                "mean_to_total_flip_to_review_n": sum(
                    row["raw_prediction"] == "approved" and row["total_prediction"] == "review required"
                    for row in total_rows
                ),
                "mean_to_total_flip_to_approve_n": sum(
                    row["raw_prediction"] == "review required" and row["total_prediction"] == "approved"
                    for row in total_rows
                ),
                "total_accuracy": total_metrics["accuracy"],
                "total_reference_discordant_approval": total_metrics["reference_discordant_approval"],
                "total_unnecessary_escalation": total_metrics["unnecessary_escalation"],
            })
            bias = json.loads(bias_path.read_text(encoding="utf-8"))
            bias_rows.append({
                "dataset": DATASET_LABEL, "scope": scope, "model": alias, "condition": condition_name,
                "content_free_bias_review_minus_approve": bias["content_free_bias_review_minus_approve"],
                "content_free_reused_from": bias.get("reused_from", "").replace("\\", "/").rsplit("/", 1)[-1],
                **{f"anchor_{row['anchor']}": row["review_minus_approve"] for row in bias["anchors"]},
            })
            for label in CONDITIONS[condition_name]["labels"]:
                candidates = [
                    next(item for item in row["candidate_scores"] if item["label"] == label) for row in rows
                ]
                counts = [item["candidate_token_count"] for item in candidates]
                token_rows.append({
                    "dataset": DATASET_LABEL, "scope": scope, "model": alias, "condition": condition_name,
                    "label": label, "semantic_class": CONDITIONS[condition_name]["semantics"][label],
                    "token_count_min": min(counts), "token_count_mode": mode(counts), "token_count_max": max(counts),
                    "unique_token_id_sequences": len({tuple(item["candidate_token_ids"]) for item in candidates}),
                    "truncated_case_n": sum(item["truncated_prefix_token_count"] > 0 for item in candidates),
                    "max_truncated_prefix_tokens": max(item["truncated_prefix_token_count"] for item in candidates),
                })
        original = {row["case_id"]: row for row in raw_by_model_condition[(alias, "original")]}
        for condition_name in CONDITIONS:
            compared = raw_by_model_condition[(alias, condition_name)]
            raw_agree = sum(row["raw_prediction"] == original[row["case_id"]]["raw_prediction"] for row in compared)
            cal_agree = sum(
                row["calibrated_prediction"] == original[row["case_id"]]["calibrated_prediction"] for row in compared
            )
            agreement_rows.append({
                "dataset": DATASET_LABEL, "scope": scope, "model": alias,
                "reference_condition": "original", "condition": condition_name, "n": len(compared),
                "raw_agreement": raw_agree / len(compared), "raw_flip_n": len(compared) - raw_agree,
                "raw_flip_to_review_n": sum(
                    original[row["case_id"]]["raw_prediction"] == "approved" and row["raw_prediction"] == "review required"
                    for row in compared
                ),
                "raw_flip_to_approve_n": sum(
                    original[row["case_id"]]["raw_prediction"] == "review required" and row["raw_prediction"] == "approved"
                    for row in compared
                ),
                "max_abs_raw_probability_change": max(
                    abs(row["raw_review_probability"] - original[row["case_id"]]["raw_review_probability"])
                    for row in compared
                ),
                "calibrated_agreement": cal_agree / len(compared), "calibrated_flip_n": len(compared) - cal_agree,
            })
        frozen_name = "batch8_repeat1_scores.json" if scope == "screen132" else "main_scores.json"
        frozen_path = ROOT / f"outputs/lab_evidence_benchmark_v2/models/{alias}/{frozen_name}"
        frozen = json.loads(frozen_path.read_text(encoding="utf-8"))
        frozen_map = {
            case_id: (choice, probability) for case_id, choice, probability in zip(
                frozen["case_ids"], frozen["selected"], frozen["review_probabilities"]
            )
        }
        new_original = raw_by_model_condition[(alias, "original")]
        selection_agreement = sum(
            row["raw_prediction"] == ("review required" if frozen_map[row["case_id"]][0] == "REVIEW_REQUIRED" else "approved")
            for row in new_original
        )
        reproduction_rows.append({
            "dataset": DATASET_LABEL, "scope": scope, "model": alias, "n": len(new_original),
            "frozen_artifact_id": f"formal-primary-{scope}-{alias}",
            "frozen_artifact_sha256": sha256(frozen_path),
            "frozen_artifact_distribution": "retained in restricted analysis environment; not distributed",
            "frozen_selection_agreement": selection_agreement / len(new_original),
            "max_abs_probability_difference": max(
                abs(row["raw_review_probability"] - frozen_map[row["case_id"]][1]) for row in new_original
            ),
        })
    reference_review = sum(row["reference"] == "review required" for row in source_rows)
    reference_approved = len(source_rows) - reference_review
    condition_rows.extend([
        {
            "dataset": DATASET_LABEL, "scope": scope, "model": "non_model", "condition": "always_review",
            "n": len(source_rows), "reference_review_required_n": reference_review,
            "reference_approved_n": reference_approved, "raw_review_n": len(source_rows),
            "raw_accuracy": reference_review / len(source_rows), "raw_reference_discordant_approval": 0.0,
            "raw_unnecessary_escalation": 1.0 if reference_approved else "NA", "calibrated_review_n": "NA",
            "calibrated_accuracy": "NA", "calibrated_reference_discordant_approval": "NA",
            "calibrated_unnecessary_escalation": "NA", "truncated_case_n": 0,
            "prefix_boundary_change_case_n": 0,
            "reused_case_n": 0, "new_inference_case_n": 0,
        },
        {
            "dataset": DATASET_LABEL, "scope": scope, "model": "non_model", "condition": "always_approve",
            "n": len(source_rows), "reference_review_required_n": reference_review,
            "reference_approved_n": reference_approved, "raw_review_n": 0,
            "raw_accuracy": reference_approved / len(source_rows), "raw_reference_discordant_approval": 1.0,
            "raw_unnecessary_escalation": 0.0 if reference_approved else "NA", "calibrated_review_n": "NA",
            "calibrated_accuracy": "NA", "calibrated_reference_discordant_approval": "NA",
            "calibrated_unnecessary_escalation": "NA", "truncated_case_n": 0,
            "prefix_boundary_change_case_n": 0,
            "reused_case_n": 0, "new_inference_case_n": 0,
        },
    ])
    write_csv(aggregate / "condition_metrics.csv", condition_rows)
    write_csv(aggregate / "agreement_and_flips_vs_original.csv", agreement_rows)
    write_csv(aggregate / "tokenization_and_truncation.csv", token_rows)
    write_csv(aggregate / "content_free_bias.csv", bias_rows)
    write_csv(aggregate / "frozen_original_reproduction.csv", reproduction_rows)
    write_csv(aggregate / "mean_vs_total_likelihood.csv", mean_total_rows)
    write_csv(aggregate / "content_free_calibration_effect.csv", calibration_effect_rows)
    if reuse_audit_rows:
        write_csv(aggregate / "reuse_audit.csv", reuse_audit_rows)
    environment_keys = (
        "model_alias", "model_id", "snapshot_revision", "parameters", "python", "platform", "torch",
        "transformers", "cuda_runtime", "device", "device_memory_bytes", "model_forward_dtype",
        "score_normalization_dtype", "full_model_fp32_run", "full_model_fp32_reason",
    )
    environments = {}
    scoring_hashes = set()
    for alias in MODELS:
        local_environment = json.loads((local / f"{alias}__environment.json").read_text(encoding="utf-8"))
        environments[alias] = {key: local_environment[key] for key in environment_keys}
        environments[alias]["scoring_script_sha256"] = local_environment["script_sha256"]
        environments[alias]["reused_case_count_per_condition"] = local_environment.get("reused_case_count_per_condition", 0)
        environments[alias]["new_inference_case_count_per_condition"] = local_environment.get(
            "new_inference_case_count_per_condition", len(source_rows)
        )
        environments[alias]["stable_command"] = (
            f"python scripts/run_path_a_scoring_robustness.py --phase score --scope {scope} --model {alias}"
        )
        scoring_hashes.add(local_environment["script_sha256"])
    manifest = {
        "run_id": "path_a_scoring_robustness_20260904",
        "status": "complete",
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "dataset": DATASET_LABEL,
        "scope": scope,
        "case_count": len(source_rows),
        "input": "public synthetic surrogate source; record-level path omitted",
        "input_sha256": sha256(INPUT),
        "script": "scripts/run_path_a_scoring_robustness.py",
        "scoring_script_sha256_values": sorted(scoring_hashes),
        "aggregation_script_sha256": sha256(Path(__file__)),
        "post_scoring_code_change": (
            "If hashes differ, only aggregate path sanitization, frozen-reference selection, and stratified reuse support "
            "were added after the earlier model-scoring screen; the candidate scoring implementation was unchanged."
        ),
        "seed": SEED,
        "batch_size": BATCH_SIZE,
        "max_length": MAX_LENGTH,
        "model_forward_dtype": "bfloat16",
        "score_normalization_dtype": "float32",
        "full_model_fp32_run": False,
        "claim_boundary": (
            "This auxiliary run evaluates scoring sensitivity on the 2026-07-28 nonclinical synthetic surrogate. "
            "It does not evaluate or reconstruct the restricted clinical 660-record analysis."
        ),
        "raw_output_policy": "Case-level scoring files are retained locally and are not included in the public package.",
        "conditions": CONDITIONS,
        "content_free_anchors": CONTENT_FREE_BODIES,
        "environments": environments,
        "aggregate_files": {path.name: sha256(path) for path in sorted(aggregate.glob("*.csv"))},
    }
    write_json(aggregate / "run_manifest.json", manifest)
    print(json.dumps({
        "scope": scope,
        "aggregate_directory": str(aggregate),
        "reproduction": reproduction_rows,
    }, ensure_ascii=False, indent=2), flush=True)


def audit(scope: str) -> None:
    from transformers import AutoTokenizer

    rows = load_rows(scope)
    result = {"dataset": DATASET_LABEL, "scope": scope, "cases": len(rows), "models": {}}
    for alias, spec in MODELS.items():
        tokenizer = AutoTokenizer.from_pretrained(
            spec["model_id"], revision=spec["revision"], local_files_only=True, trust_remote_code=True
        )
        model_result = {}
        for condition_name, condition in CONDITIONS.items():
            prompt = condition_prompt(rows[0], condition)
            prefix = tokenizer.apply_chat_template(
                [{"role": "user", "content": prompt}], tokenize=False, add_generation_prompt=True
            ) if getattr(tokenizer, "chat_template", None) else f"User: {prompt}\nAssistant:"
            model_result[condition_name] = {
                label: tokenizer.convert_ids_to_tokens(tokenizer(prefix + label, add_special_tokens=False)["input_ids"][-20:])
                for label in condition["labels"]
            }
        result["models"][alias] = model_result
    print(json.dumps(result, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("audit", "score", "summarize"), required=True)
    parser.add_argument("--scope", choices=("screen132", "stratified132", "full660"), required=True)
    parser.add_argument("--model", choices=tuple(MODELS))
    args = parser.parse_args()
    if args.phase == "audit":
        audit(args.scope)
    elif args.phase == "score":
        if not args.model:
            parser.error("--model is required for --phase score")
        score_model(args.scope, args.model)
    else:
        summarize(args.scope)


if __name__ == "__main__":
    main()
