from __future__ import annotations

import asyncio
import csv
import hashlib
import importlib.metadata
import json
import os
import platform
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import prescription_mcp.orchestrator as orchestrator_module
from prescription_mcp.orchestrator import PrescriptionReviewOrchestrator
from prescription_mcp.safe_boundary import (
    AUTO_PASS_ELIGIBLE,
    AUTHORITY_CONTRACT_VERSION,
    HUMAN_REVIEW_REQUIRED,
    enforce_authority,
)
from scripts.run_lab_evidence_benchmark import FAULTS, SEED, build_corpus, decision_signature


OUTPUT = ROOT / "outputs/forced_approved_contract_assay_20260905"
MODEL_CANDIDATE = "APPROVED"

DETECTORS = {
    "missing": lambda issue: "missing required laboratory evidence" in issue,
    "stale": lambda issue: " is stale" in issue,
    "unit_error": lambda issue: "unexpected " in issue and " unit " in issue and "unexpected dose unit" not in issue,
    "conflict": lambda issue: issue.startswith("conflicting ") or ": conflicting " in issue,
    "wrong_encounter": lambda issue: "belongs to another encounter" in issue,
    "service_failure": lambda issue: issue == "laboratory MCP service unavailable",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


async def collect_mcp_reviews(cases: list[dict]) -> list[dict]:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    params = StdioServerParameters(
        command=sys.executable,
        args=[str(ROOT / "mcp_server.py"), "--transport", "stdio"],
        cwd=ROOT,
    )
    decisions = []
    with open(os.devnull, "w", encoding="utf-8") as errlog:
        async with stdio_client(params, errlog=errlog) as streams:
            async with ClientSession(*streams) as session:
                await session.initialize()
                for case in cases:
                    result = await session.call_tool(
                        "review_prescription",
                        {"payload": case["payload"], "force_fallback": True},
                    )
                    if result.isError or not isinstance(result.structuredContent, dict):
                        raise RuntimeError(f"MCP review failed for {case['case_id']}")
                    decisions.append(result.structuredContent)
    return decisions


def evaluate_direct(cases: list[dict]) -> list[dict]:
    orchestrator = PrescriptionReviewOrchestrator()
    return [orchestrator.review(case["payload"], force_fallback=True) for case in cases]


def forced_outcome(decision: dict) -> str:
    return enforce_authority(MODEL_CANDIDATE, decision)["decision"]


def summarize_forced_assay(cases: list[dict], direct: list[dict], mcp: list[dict]) -> tuple[dict, list[dict], list[dict]]:
    comparisons = []
    for case, direct_decision, mcp_decision in zip(cases, direct, mcp):
        comparisons.append({
            "case": case,
            "direct_mcp_equal": decision_signature(direct_decision) == decision_signature(mcp_decision),
            "direct_outcome": forced_outcome(direct_decision),
            "mcp_outcome": forced_outcome(mcp_decision),
        })
    if not all(row["direct_mcp_equal"] and row["direct_outcome"] == row["mcp_outcome"] for row in comparisons):
        raise RuntimeError("Direct and MCP contract outcomes diverged")

    faults = [row for row in comparisons if row["case"]["state"] in FAULTS]
    clean_approved = [row for row in comparisons if row["case"]["state"] == "clean" and row["case"]["reference"] == "approved"]
    clean_review = [row for row in comparisons if row["case"]["state"] == "clean" and row["case"]["reference"] == "review required"]

    by_fault_domain = []
    for fault in FAULTS:
        for domain in sorted({row["case"]["domain"] for row in faults}):
            group = [row for row in faults if row["case"]["state"] == fault and row["case"]["domain"] == domain]
            by_fault_domain.append({
                "fault": fault,
                "domain": domain,
                "n": len(group),
                "forced_approved_revoked": sum(row["mcp_outcome"] == HUMAN_REVIEW_REQUIRED for row in group),
                "direct_mcp_equal": sum(row["direct_mcp_equal"] for row in group),
            })

    clean_by_domain = []
    for reference, group in (("approved", clean_approved), ("review required", clean_review)):
        for domain in sorted({row["case"]["domain"] for row in group}):
            subset = [row for row in group if row["case"]["domain"] == domain]
            clean_by_domain.append({
                "reference": reference,
                "domain": domain,
                "n": len(subset),
                "auto_pass_eligible": sum(row["mcp_outcome"] == AUTO_PASS_ELIGIBLE for row in subset),
                "human_review_required": sum(row["mcp_outcome"] == HUMAN_REVIEW_REQUIRED for row in subset),
            })

    fault_counts = Counter(row["case"]["state"] for row in faults)
    domain_counts = Counter(row["case"]["domain"] for row in faults)
    summary = {
        "scope": "post_hoc_nonclinical_public_synthetic_contract_assay",
        "model_candidate": MODEL_CANDIDATE,
        "main_records": len(comparisons),
        "observable_fault_records": len(faults),
        "observable_faults_revoked": sum(row["mcp_outcome"] == HUMAN_REVIEW_REQUIRED for row in faults),
        "observable_faults_by_type": {
            fault: {
                "n": fault_counts[fault],
                "revoked": sum(row["case"]["state"] == fault and row["mcp_outcome"] == HUMAN_REVIEW_REQUIRED for row in faults),
            }
            for fault in FAULTS
        },
        "observable_faults_by_domain": {
            domain: {
                "n": domain_counts[domain],
                "revoked": sum(row["case"]["domain"] == domain and row["mcp_outcome"] == HUMAN_REVIEW_REQUIRED for row in faults),
            }
            for domain in sorted(domain_counts)
        },
        "clean_reference_approved": {
            "n": len(clean_approved),
            "auto_pass_eligible": sum(row["mcp_outcome"] == AUTO_PASS_ELIGIBLE for row in clean_approved),
            "human_review_required": sum(row["mcp_outcome"] == HUMAN_REVIEW_REQUIRED for row in clean_approved),
        },
        "clean_reference_review_required": {
            "n": len(clean_review),
            "human_review_required": sum(row["mcp_outcome"] == HUMAN_REVIEW_REQUIRED for row in clean_review),
        },
        "direct_mcp_equal": sum(row["direct_mcp_equal"] for row in comparisons),
        "direct_mcp_compared": len(comparisons),
    }
    return summary, by_fault_domain, clean_by_domain


def run_mutations(cases: list[dict]) -> list[dict]:
    fault_cases = [case for case in cases if case["state"] in FAULTS]
    clean_approved = [case for case in cases if case["state"] == "clean" and case["reference"] == "approved"]
    original = orchestrator_module._lab_evidence_issues
    rows = []
    try:
        for fault, matches in DETECTORS.items():
            target = [case for case in fault_cases if case["state"] == fault]
            non_target = [case for case in fault_cases if case["state"] != fault]
            baseline = evaluate_direct(target)

            def mutated(prescription, rules, payload, detector=matches):
                return [issue for issue in original(prescription, rules, payload) if not detector(issue)]

            orchestrator_module._lab_evidence_issues = mutated
            target_mutant = evaluate_direct(target)
            non_target_mutant = evaluate_direct(non_target)
            clean_mutant = evaluate_direct(clean_approved)
            baseline_hits = sum(any(matches(issue) for issue in result["coverage_issues"]) for result in baseline)
            mutant_hits = sum(any(matches(issue) for issue in result["coverage_issues"]) for result in target_mutant)
            leaks = sum(forced_outcome(result) == AUTO_PASS_ELIGIBLE for result in target_mutant)
            rows.append({
                "disabled_detector": fault,
                "target_fault_n": len(target),
                "baseline_target_detector_hits": baseline_hits,
                "mutant_target_detector_hits": mutant_hits,
                "target_final_auto_pass_leaks": leaks,
                "target_still_review_due_overlapping_guards": len(target) - leaks,
                "non_target_fault_n": len(non_target),
                "non_target_faults_still_review": sum(forced_outcome(result) == HUMAN_REVIEW_REQUIRED for result in non_target_mutant),
                "clean_reference_approved_n": len(clean_approved),
                "clean_reference_approved_auto_pass": sum(forced_outcome(result) == AUTO_PASS_ELIGIBLE for result in clean_mutant),
            })
    finally:
        orchestrator_module._lab_evidence_issues = original
    return rows


def validate(summary: dict, by_fault_domain: list[dict], mutations: list[dict]) -> None:
    if summary["observable_faults_revoked"] != 264:
        raise RuntimeError("Forced APPROVED was not revoked for all observable faults")
    if any(row["n"] != 4 or row["forced_approved_revoked"] != 4 or row["direct_mcp_equal"] != 4 for row in by_fault_domain):
        raise RuntimeError("At least one fault-domain cell failed")
    if summary["clean_reference_approved"] != {"n": 132, "auto_pass_eligible": 120, "human_review_required": 12}:
        raise RuntimeError("Clean approved-control count changed")
    if summary["clean_reference_review_required"] != {"n": 132, "human_review_required": 132}:
        raise RuntimeError("Clean review-control count changed")
    expected_leaks = {
        "missing": 40,
        "stale": 20,
        "unit_error": 20,
        "conflict": 0,
        "wrong_encounter": 20,
        "service_failure": 20,
    }
    for row in mutations:
        fault = row["disabled_detector"]
        if row["baseline_target_detector_hits"] != 44 or row["mutant_target_detector_hits"] != 0:
            raise RuntimeError(f"Detector mutation did not isolate {fault}")
        if row["target_final_auto_pass_leaks"] != expected_leaks[fault]:
            raise RuntimeError(f"Unexpected final-decision leakage for {fault}")
        if row["non_target_faults_still_review"] != 220:
            raise RuntimeError(f"Non-target blocking changed for {fault}")


def main() -> None:
    if OUTPUT.exists():
        raise FileExistsError(f"Refusing to overwrite frozen output: {OUTPUT}")
    main_cases, _ = build_corpus()
    direct = evaluate_direct(main_cases)
    mcp = asyncio.run(collect_mcp_reviews(main_cases))
    summary, by_fault_domain, clean_by_domain = summarize_forced_assay(main_cases, direct, mcp)
    mutations = run_mutations(main_cases)
    validate(summary, by_fault_domain, mutations)

    contract_files = [
        ROOT / "scripts/run_forced_approved_contract_assay.py",
        ROOT / "scripts/run_lab_evidence_benchmark.py",
        ROOT / "prescription_mcp/orchestrator.py",
        ROOT / "prescription_mcp/safe_boundary.py",
        ROOT / "prescription_mcp/data/drug_domains_19.json",
        ROOT / "mcp_server.py",
        ROOT / "data/public/raw/synthea_sample_data_csv_apr2020.zip",
    ]
    run_contract = {
        "scope": summary["scope"],
        "seed": SEED,
        "model_candidate": MODEL_CANDIDATE,
        "authority_contract_version": AUTHORITY_CONTRACT_VERSION,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "mcp": importlib.metadata.version("mcp"),
        "files": {
            path.relative_to(ROOT).as_posix(): sha256(path)
            for path in contract_files
        },
    }
    readme = """# Forced-APPROVED authority-contract assay

This post hoc, non-clinical assay rebuilds the public synthetic 660-record surrogate and evaluates its 528 main records. A literal `APPROVED` candidate is passed to the caller authority boundary after both an in-process review and a review through one reused MCP stdio session.

The assay is a software-conformance test. It does not use the restricted clinical-derived case files, rerun the formal model evaluation, validate the clinical rules, or establish patient safety.

`forced_approved_by_fault_domain.csv` contains only aggregate 4-case cells. `clean_control_by_domain.csv` reports reference-approved and reference-review-required clean controls. `mutation_matrix.csv` disables one observable-integrity detector at a time. Final-decision leakage can remain masked by overlapping threshold or input guards; detector-signal removal and final leakage are therefore reported separately.

The 12 reference-approved clean controls that remain review-required are all heparin scenarios affected by the frozen generic non-mg dose-unit guard. The guard was not changed post hoc because doing so would alter the evaluated contract and require a complete rerun of the restricted and public analyses.
"""

    OUTPUT.mkdir(parents=True)
    (OUTPUT / "forced_approved_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    write_csv(OUTPUT / "forced_approved_by_fault_domain.csv", by_fault_domain)
    write_csv(OUTPUT / "clean_control_by_domain.csv", clean_by_domain)
    write_csv(OUTPUT / "mutation_matrix.csv", mutations)
    (OUTPUT / "RUN_CONTRACT.json").write_text(json.dumps(run_contract, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUTPUT / "README.md").write_text(readme, encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
