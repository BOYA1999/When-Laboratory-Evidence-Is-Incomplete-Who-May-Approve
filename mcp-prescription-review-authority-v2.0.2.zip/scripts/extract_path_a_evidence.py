from __future__ import annotations

import csv
import json
import os
import re
from pathlib import Path

from transformers import AutoTokenizer


ROOT = Path(__file__).resolve().parents[1]
BENCHMARK = ROOT / "outputs" / "lab_evidence_benchmark_v2"
OUTPUT = ROOT / "outputs" / "path_a_reanalysis_20260904"
NA = "NA"
CHOICES = ("REVIEW_REQUIRED", "APPROVED")


def value(item: object) -> object:
    return NA if item is None or item == "" else item


def snapshot_for(model_id: str) -> Path | None:
    cache_root = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface")) / "hub"
    snapshots = cache_root / ("models--" + model_id.replace("/", "--")) / "snapshots"
    found = sorted(path for path in snapshots.glob("*") if path.is_dir()) if snapshots.exists() else []
    return found[0] if len(found) == 1 else None


def candidate_counts(tokenizer: object, prompts: list[str]) -> dict[str, dict[str, object]]:
    counts = {choice: [] for choice in CHOICES}
    has_template = bool(getattr(tokenizer, "chat_template", None))
    for prompt in prompts:
        prefix = (
            tokenizer.apply_chat_template(
                [{"role": "user", "content": prompt}], tokenize=False, add_generation_prompt=True
            )
            if has_template
            else f"User: {prompt}\nAssistant:"
        )
        prefix_length = len(tokenizer(prefix, add_special_tokens=False)["input_ids"])
        for choice in CHOICES:
            full_length = len(tokenizer(prefix + choice, add_special_tokens=False)["input_ids"])
            counts[choice].append(full_length - prefix_length)
    return {
        choice: {
            "minimum": min(items),
            "maximum": max(items),
            "observed_values": sorted(set(items)),
        }
        for choice, items in counts.items()
    }


def write_registry() -> None:
    registry = json.loads((ROOT / "prescription_mcp" / "data" / "drug_domains_19.json").read_text(encoding="utf-8"))
    raw_labels = json.loads((ROOT / "data" / "public" / "raw" / "lab_domain_openfda_labels.json").read_text(encoding="utf-8"))
    fields = [
        "canonical_drug", "required_lab", "required_unit", "freshness_window_days", "trigger",
        "threshold_operator", "threshold_value", "label_manufacturer", "label_effective_date",
        "label_retrieved_at", "label_set_id", "label_version", "rule_id", "rule_version", "schema_version",
    ]
    rows = []
    for domain in registry.get("domains", []):
        lab_rules = [rule for rule in domain.get("rules", []) if rule.get("lab_name")]
        if not lab_rules:
            continue
        if len(lab_rules) != 1:
            raise ValueError(f"Expected one laboratory rule for {domain.get('canonical_name', NA)}")
        rule = lab_rules[0]
        label = domain.get("label", {})
        rows.append({
            "canonical_drug": value(domain.get("canonical_name")),
            "required_lab": value(rule.get("lab_name")),
            "required_unit": value(rule.get("lab_unit")),
            "freshness_window_days": value(rule.get("max_age_days")),
            "trigger": value(rule.get("condition_text")),
            "threshold_operator": value(rule.get("threshold_operator")),
            "threshold_value": value(rule.get("threshold")),
            "label_manufacturer": value(label.get("manufacturer")),
            "label_effective_date": value(label.get("effective_date")),
            "label_retrieved_at": value(raw_labels.get("retrieved_at")),
            "label_set_id": value(label.get("set_id")),
            "label_version": value(label.get("version")),
            "rule_id": value(rule.get("id")),
            "rule_version": value(rule.get("version")),
            "schema_version": value(registry.get("schema_version")),
        })
    if len(rows) != 11:
        raise ValueError(f"Expected 11 laboratory domains, found {len(rows)}")
    with (OUTPUT / "laboratory_contract_registry.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_environment() -> None:
    contract = json.loads((BENCHMARK / "RUN_CONTRACT.json").read_text(encoding="utf-8"))
    prompts = [json.loads(line)["prompt"] for line in (BENCHMARK / "prepared_mcp_contexts_660.jsonl").read_text(encoding="utf-8").splitlines() if line]
    source = (ROOT / "scripts" / "run_lab_evidence_benchmark.py").read_text(encoding="utf-8")
    match = re.search(r"max_length\s*=\s*(\d+)", source)
    max_length: object = int(match.group(1)) if match else NA
    models = []
    for alias, public_id in contract.get("models", {}).items():
        main_path = BENCHMARK / "models" / alias / "main_scores.json"
        main = json.loads(main_path.read_text(encoding="utf-8")) if main_path.exists() else {}
        metadata = main.get("model", {})
        snapshot = snapshot_for(public_id)
        if snapshot:
            tokenizer = AutoTokenizer.from_pretrained(snapshot, local_files_only=True, trust_remote_code=True)
            template_usage = (
                "tokenizer.apply_chat_template with one user message, tokenize=False, add_generation_prompt=True"
                if getattr(tokenizer, "chat_template", None)
                else "fallback prefix: User: {prompt}\\nAssistant:"
            )
            token_counts: object = candidate_counts(tokenizer, prompts)
        else:
            template_usage = NA
            token_counts = NA
        stage_batches = []
        for score_path in sorted((BENCHMARK / "models" / alias).glob("*_scores.json")):
            score = json.loads(score_path.read_text(encoding="utf-8"))
            if score.get("batch_size") is not None:
                stage_batches.append(score["batch_size"])
        models.append({
            "alias": alias,
            "public_model_id": public_id,
            "snapshot_revision": snapshot.name if snapshot else NA,
            "parameters": value(metadata.get("parameters")),
            "dtype": value(metadata.get("dtype")),
            "device": value(metadata.get("device")),
            "pytorch": value(metadata.get("torch")),
            "transformers": value(metadata.get("transformers")),
            "maximum_input_length_tokens": max_length,
            "chat_template_usage": template_usage,
            "seed": value(contract.get("seed")),
            "primary_batch_size": value(main.get("batch_size")),
            "observed_scoring_batch_sizes": sorted(set(stage_batches)) if stage_batches else NA,
            "candidate_token_counts_across_660_prompts": token_counts,
        })
    payload = {
        "scope": "Aggregate reproducibility metadata extracted from the frozen local workspace; no patient-level content.",
        "candidate_labels": list(CHOICES),
        "models": models,
    }
    (OUTPUT / "reproducibility_environment.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    write_registry()
    write_environment()


if __name__ == "__main__":
    main()
