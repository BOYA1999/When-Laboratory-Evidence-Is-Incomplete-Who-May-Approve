from __future__ import annotations

import shutil
import sys
from pathlib import Path

from verify_release import (
    LEGACY_DIR,
    CheckError,
    check_file,
    load_legacy_entries,
    safe_path,
)


ROOT = Path(__file__).resolve().parents[1]
DESTINATION = ROOT / "outputs/lab_evidence_benchmark_v2"


def main() -> int:
    if len(sys.argv) != 1:
        print("FAIL: restore_public_surrogate.py takes no arguments", file=sys.stderr)
        return 2
    try:
        entries = load_legacy_entries()
        pending = []
        skipped = 0
        conflicts = []
        for relative, size, sha256, git_blob in entries:
            source = safe_path(LEGACY_DIR, relative)
            target = safe_path(DESTINATION, relative)
            check_file(source, size, sha256, git_blob)
            if target.exists():
                try:
                    check_file(target, size, sha256, git_blob)
                except CheckError:
                    conflicts.append(relative)
                else:
                    skipped += 1
            else:
                pending.append((source, target, size, sha256, git_blob))
        if conflicts:
            raise CheckError(
                "existing targets differ; nothing restored: " + ", ".join(sorted(conflicts))
            )

        for source, target, size, sha256, git_blob in pending:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            check_file(target, size, sha256, git_blob)
    except CheckError as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"FAIL: restore failed: {exc}", file=sys.stderr)
        return 1
    print(f"PASS: restored {len(pending)}, skipped identical {skipped}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
