# Model Sources

No language-model weights are included. Candidate scores and decisions under `legacy/public_synthetic_20260728/` belong to the public synthetic software run, not the restricted clinical analysis. Current paper-facing results are distributed as aggregates.

| Local alias | Upstream model ID | Recorded role | Upstream license |
| --- | --- | --- | --- |
| `qwen2.5-3b` | [Qwen/Qwen2.5-3B-Instruct](https://huggingface.co/Qwen/Qwen2.5-3B-Instruct) | Two-candidate scoring | Qwen Research License; non-commercial research/evaluation unless separately licensed |
| `smollm2-1.7b` | [HuggingFaceTB/SmolLM2-1.7B-Instruct](https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B-Instruct) | Two-candidate scoring | Apache-2.0 |
| `phi3.5-mini` | [microsoft/Phi-3.5-mini-instruct](https://huggingface.co/microsoft/Phi-3.5-mini-instruct) | Two-candidate scoring | MIT |

The public run's model IDs, random seed, forced-choice score threshold, bootstrap count, and core-file hashes are stored in `outputs/lab_evidence_benchmark_v2/RUN_CONTRACT.json`. The normalized score is not a calibrated clinical probability. The small public policy-router artifact (`prescription_mcp/data/router_model_public.joblib`) is included; it is not an LLM checkpoint.

## Reproduction limit

The original public run contract did not store immutable Hugging Face commit revisions for the three model repositories. A future download under the same model ID may differ. The later snapshot inventory in `outputs/path_a_reanalysis_20260904/model_snapshot_manifest.csv` documents public post hoc work, not the exact model lineage of the restricted clinical run. The legacy scores allow inspection of the synthetic run only; they do not verify confidential clinical scores or labels.

The scoring-robustness script requires PyTorch and CUDA/bfloat16 for `score`; its `audit` phase uses cached tokenizers without GPU inference. Restoring the 20 legacy files alone is insufficient for `summarize`, which also needs the non-distributed scoring-sensitivity intermediates. See the README for the distinct verification and rerun routes.

Before downloading or running a model:

1. Read and accept the current upstream model license.
2. Confirm that the intended use is permitted, especially for Qwen2.5-3B-Instruct.
3. Install a PyTorch build that matches the local hardware and CUDA runtime.
4. Use a new output directory; reported score files are immutable evidence.

The repository MIT License does not grant rights to any model, tokenizer, model code, or weight file.
