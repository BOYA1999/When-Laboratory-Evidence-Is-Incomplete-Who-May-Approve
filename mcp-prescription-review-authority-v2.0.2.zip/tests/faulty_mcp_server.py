from __future__ import annotations

import argparse
import os
import sys
import time
from typing import Any

from mcp.server.fastmcp import FastMCP


mcp = FastMCP("Path A fault fixture", json_response=True)


@mcp.tool()
def get_lab_review_context(payload: dict[str, Any]) -> dict[str, Any]:
    fault = payload.get("_fault")
    if fault == "context_timeout":
        time.sleep(0.4)
    if fault == "context_error":
        raise RuntimeError("injected context error")
    if fault == "malformed_json":
        os.write(sys.stdout.fileno(), b"not-json\n")
    if fault == "non_object_context":
        return "not-an-object"
    if fault == "exit_context":
        os._exit(17)
    return {
        "patient_context": {},
        "medications": payload.get("medications", []),
        "laboratory_evidence": payload.get("patient", {}).get("labs", []),
        "data_quality_notices": [],
        "rules": [],
    }


@mcp.tool()
def review_prescription(payload: dict[str, Any], force_fallback: bool = False) -> dict[str, Any]:
    fault = payload.get("_fault")
    if fault == "review_timeout":
        time.sleep(0.4)
    if fault == "review_error":
        raise RuntimeError("injected review error")
    if fault == "missing_status":
        return {"coverage_status": "validated", "coverage_issues": []}
    if fault == "non_object_review":
        return ["not-an-object"]
    if fault == "exit_review":
        os._exit(17)
    return {"status": "approved", "coverage_status": "validated", "coverage_issues": []}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--transport", choices=["stdio"], default="stdio")
    parser.parse_args()
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
