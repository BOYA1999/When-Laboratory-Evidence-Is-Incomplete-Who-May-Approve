from scripts.run_forced_approved_contract_assay import (
    evaluate_direct,
    forced_outcome,
    run_mutations,
)
from scripts.run_lab_evidence_benchmark import FAULTS, build_corpus


def test_forced_approved_public_synthetic_contract() -> None:
    main, _ = build_corpus()
    faults = [case for case in main if case["state"] in FAULTS]
    outcomes = [forced_outcome(result) for result in evaluate_direct(faults)]
    assert len(faults) == 264
    assert outcomes.count("HUMAN_REVIEW_REQUIRED") == 264


def test_detector_mutations_are_observable_and_isolated() -> None:
    main, _ = build_corpus()
    rows = {row["disabled_detector"]: row for row in run_mutations(main)}
    assert set(rows) == set(FAULTS)
    assert all(row["baseline_target_detector_hits"] == 44 for row in rows.values())
    assert all(row["mutant_target_detector_hits"] == 0 for row in rows.values())
    assert all(row["non_target_faults_still_review"] == 220 for row in rows.values())
    assert {key: value["target_final_auto_pass_leaks"] for key, value in rows.items()} == {
        "missing": 40,
        "stale": 20,
        "unit_error": 20,
        "conflict": 0,
        "wrong_encounter": 20,
        "service_failure": 20,
    }
