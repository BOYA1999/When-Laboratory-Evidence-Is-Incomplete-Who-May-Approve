# Forced-APPROVED authority-contract assay

This post hoc, non-clinical assay rebuilds the public synthetic 660-record surrogate and evaluates its 528 main records. A literal `APPROVED` candidate is passed to the caller authority boundary after both an in-process review and a review through one reused MCP stdio session.

The assay is a software-conformance test. It does not use the restricted clinical-derived case files, rerun the formal model evaluation, validate the clinical rules, or establish patient safety.

`forced_approved_by_fault_domain.csv` contains only aggregate 4-case cells. `clean_control_by_domain.csv` reports reference-approved and reference-review-required clean controls. `mutation_matrix.csv` disables one observable-integrity detector at a time. Final-decision leakage can remain masked by overlapping threshold or input guards; detector-signal removal and final leakage are therefore reported separately.

The 12 reference-approved clean controls that remain review-required are all heparin scenarios affected by the frozen generic non-mg dose-unit guard. The guard was not changed post hoc because doing so would alter the evaluated contract and require a complete rerun of the restricted and public analyses.
