# Path A protocol latency assay

Aggregate-only local, post hoc, nonclinical stdio results. No restricted record, identifier, network transport, concurrent request, or model inference was used.

- Warm direct context: n=500, median 0.031 ms, Q1-Q3 0.030-0.032 ms, IQR 0.001 ms, P95 0.036 ms.
- Warm MCP context: n=500, median 1.916 ms, Q1-Q3 1.859-2.007 ms, IQR 0.149 ms, P95 2.398 ms.
- Warm direct review: n=500, median 0.175 ms, Q1-Q3 0.170-0.180 ms, IQR 0.010 ms, P95 0.191 ms.
- Warm MCP review: n=500, median 2.229 ms, Q1-Q3 2.168-2.335 ms, IQR 0.167 ms, P95 2.707 ms.
- Cold new-session initialization: n=20, median 1033.034 ms, Q1-Q3 1020.885-1063.388 ms, IQR 42.502 ms, P95 1081.737 ms.
- New-session recovery after server exit: n=10, median 1085.231 ms, Q1-Q3 1064.758-1095.648 ms, IQR 30.889 ms, P95 1110.403 ms.

Run with `.venv/Scripts/python.exe scripts/run_path_a_protocol_latency.py`.

Boundary: one machine and local stdio only; no inference about deployment, network, concurrency, pharmacist workflow, clinical latency, or safety.
