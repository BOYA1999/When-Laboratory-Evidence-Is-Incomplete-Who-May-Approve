# Path A existing-result reanalysis

This directory contains aggregate-only reanalysis of the retained 28 July 2026 non-clinical synthetic surrogate. It adds always-review/always-auto-pass baselines, clean/observable-fault/silent-boundary strata, reference-separated endpoints, paired domain-bootstrap risk differences, a reader-facing score-threshold summary, and batch-size shift summaries. These outputs do not establish robustness of the confidential clinical 660-record analysis.
