from __future__ import annotations

import hashlib
import json
import os
import sys
from datetime import timedelta
from pathlib import Path
from typing import Any


HUMAN_REVIEW_REQUIRED = "HUMAN_REVIEW_REQUIRED"
AUTO_PASS_ELIGIBLE = "AUTO_PASS_ELIGIBLE"
AUTHORITY_CONTRACT_VERSION = "path-a-caller-fail-closed-v1"


def local_contract_info(root: Path, server_path: Path) -> dict[str, str]:
    root = root.resolve()
    server_path = server_path.resolve()
    orchestrator_path = root / "prescription_mcp" / "orchestrator.py"
    registry_path = root / "prescription_mcp" / "data" / "drug_domains_19.json"
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    rule_versions = [
        {
            "domain": domain["canonical_name"],
            "set_id": domain["label"]["set_id"],
            "version": domain["label"]["version"],
            "rule_ids": sorted(rule["id"] for rule in domain["rules"]),
        }
        for domain in registry["domains"]
    ]
    return {
        "authority_contract_version": AUTHORITY_CONTRACT_VERSION,
        "registry_schema_version": registry["schema_version"],
        "rule_versions_sha256": hashlib.sha256(
            json.dumps(rule_versions, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest(),
        "server_sha256": _sha256(server_path),
        "orchestrator_sha256": _sha256(orchestrator_path),
        "registry_sha256": _sha256(registry_path),
    }


def enforce_authority(model_candidate: str, contract_result: dict[str, Any]) -> dict[str, Any]:
    status = str(contract_result["status"]).strip().lower()
    contract_requires_review = status != "approved"
    model_approved = model_candidate.strip() == "APPROVED"
    if contract_requires_review:
        decision, reason = HUMAN_REVIEW_REQUIRED, "contract_requires_review"
    elif not model_approved:
        decision, reason = HUMAN_REVIEW_REQUIRED, "model_not_exact_approved"
    else:
        decision, reason = AUTO_PASS_ELIGIBLE, "contract_and_model_allow_auto_pass"
    return {
        "decision": decision,
        "reason": reason,
        "caller_fail_closed": decision == HUMAN_REVIEW_REQUIRED,
        "contract_requires_review": contract_requires_review,
        "model_candidate": model_candidate,
        "mcp_status": status,
    }


async def safe_review_via_stdio(
    root: Path,
    server_path: Path,
    payload: dict[str, Any],
    model_candidate: str,
    expected_contract: dict[str, str],
    context_timeout_seconds: float = 1.0,
    review_timeout_seconds: float = 1.0,
) -> dict[str, Any]:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    root = root.resolve()
    server_path = server_path.resolve()
    actual_contract = local_contract_info(root, server_path)
    if actual_contract != expected_contract:
        return _fallback("contract_or_rule_version_mismatch", model_candidate, actual_contract)
    issues = _input_integrity_issues(payload)
    if issues:
        result = _fallback("input_integrity_failure", model_candidate, actual_contract)
        result["input_issues"] = issues
        return result

    params = StdioServerParameters(
        command=sys.executable,
        args=[str(server_path), "--transport", "stdio"],
        cwd=root,
    )
    stage = "initialize"
    call_failure_reason = None
    protocol_errors: list[str] = []

    async def capture_protocol_error(message: Any) -> None:
        if isinstance(message, Exception):
            protocol_errors.append(type(message).__name__)

    try:
        with open(os.devnull, "w", encoding="utf-8") as errlog:
            async with stdio_client(params, errlog=errlog) as streams:
                async with ClientSession(
                    *streams,
                    read_timeout_seconds=timedelta(seconds=max(5.0, context_timeout_seconds, review_timeout_seconds)),
                    message_handler=capture_protocol_error,
                ) as session:
                    await session.initialize()
                    stage = "context"
                    try:
                        context_result = await session.call_tool(
                            "get_lab_review_context",
                            {"payload": payload},
                            read_timeout_seconds=timedelta(seconds=context_timeout_seconds),
                        )
                    except Exception as exc:
                        call_failure_reason = f"context_{'timeout' if _contains_timeout(exc) else 'failure'}"
                        raise
                    if protocol_errors:
                        raise ValueError("malformed MCP protocol message")
                    _validated_content(
                        context_result,
                        {"patient_context", "medications", "laboratory_evidence", "data_quality_notices", "rules"},
                    )
                    stage = "review"
                    try:
                        review_result = await session.call_tool(
                            "review_prescription",
                            {"payload": payload, "force_fallback": True},
                            read_timeout_seconds=timedelta(seconds=review_timeout_seconds),
                        )
                    except Exception as exc:
                        call_failure_reason = f"review_{'timeout' if _contains_timeout(exc) else 'failure'}"
                        raise
                    if protocol_errors:
                        raise ValueError("malformed MCP protocol message")
                    review = _validated_content(
                        review_result,
                        {"status", "coverage_status", "coverage_issues"},
                    )
    except Exception as exc:
        reason = call_failure_reason or f"{stage}_{'timeout' if _contains_timeout(exc) else 'failure'}"
        result = _fallback(reason, model_candidate, actual_contract)
        result["exception_type"] = type(exc).__name__
        return result

    result = enforce_authority(model_candidate, review)
    result["contract_info"] = actual_contract
    return result


def _validated_content(result: Any, required: set[str]) -> dict[str, Any]:
    if getattr(result, "isError", False):
        raise ValueError("MCP tool returned an error")
    content = getattr(result, "structuredContent", None)
    if not isinstance(content, dict):
        raise TypeError("MCP structured content is not an object")
    missing = required - content.keys()
    if missing:
        raise ValueError("MCP structured content is missing required fields")
    return content


def _input_integrity_issues(payload: Any) -> list[str]:
    if not isinstance(payload, dict):
        return ["payload is not an object"]
    patient = payload.get("patient", {})
    if not isinstance(patient, dict):
        return ["patient is not an object"]
    labs = patient.get("labs", payload.get("labs", []))
    if not isinstance(labs, list):
        return ["laboratory evidence is not an array"]
    seen: set[str] = set()
    for lab in labs:
        if not isinstance(lab, dict):
            continue
        signature = json.dumps(lab, sort_keys=True, separators=(",", ":"), default=str)
        if signature in seen:
            return ["exact duplicate laboratory observation"]
        seen.add(signature)
    return []


def _fallback(reason: str, model_candidate: str, contract_info: dict[str, str]) -> dict[str, Any]:
    return {
        "decision": HUMAN_REVIEW_REQUIRED,
        "reason": reason,
        "caller_fail_closed": True,
        "contract_requires_review": None,
        "model_candidate": model_candidate,
        "mcp_status": None,
        "contract_info": contract_info,
    }


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _contains_timeout(exc: BaseException) -> bool:
    if isinstance(exc, TimeoutError) or "timed out" in str(exc).lower():
        return True
    return any(_contains_timeout(child) for child in getattr(exc, "exceptions", ()))
