# Public synthetic software run, 28 July 2026

These 20 files are preserved byte-for-byte from public tag `1.1`, commit `3d7fdda0164a82d72615e0e5fed40342921cc227`, of [the project repository](https://github.com/BOYA1999/When-Laboratory-Evidence-Is-Incomplete-Who-May-Approve). The author confirmed that all 20 are purely synthetic and authorized for public distribution. `SOURCE_MANIFEST.json` records each original Git blob hash, size, and current SHA-256.

The two JSONL files contain 660 synthetic prescriptions and their prepared MCP contexts. Each of the three model directories contains the original main score file, three batch/repeat score files, predictions, and a combined score/stability file. Aliases are defined in `MODEL_SOURCES.md`; fields and units follow the frozen benchmark script and laboratory registry. APPROVED and HUMAN_REVIEW are software decisions, not patient outcomes. Case identifiers are synthetic keys.

This historical software test is separate from the restricted clinical source pool, the selected clinical analysis, and the pharmacist reference. It cannot reconstruct the confidential 1,540-to-660 mapping. Its dates, model scores, and later snapshot checks must not be presented as clinical-run provenance.

For compatibility with archival scripts that read the former paths, make a disposable copy of the repository and run `python scripts/restore_public_surrogate.py` there. The helper verifies all 20 files before copying them to `outputs/lab_evidence_benchmark_v2/`; it refuses to overwrite differing files. Do not run follow-on reanalysis in the preserved release tree: several scripts overwrite aggregate outputs, and new synthetic reruns are not replacements for reported clinical evidence. The scoring-sensitivity intermediate files are not supplied, so these 20 files alone do not enable its `summarize` phase.

The repository code license and upstream data/model terms remain as documented in `LICENSE`, `DATA_SOURCES.md`, and `MODEL_SOURCES.md`. This organization preserves the old public files without changing the historical tag.
