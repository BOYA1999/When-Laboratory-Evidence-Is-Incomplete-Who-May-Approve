# Application-Level Auto-Pass Authority for MCP Prescription Review

This research package implements an application contract that decides whether a language-model candidate remains eligible for automated pass in laboratory-linked prescription review. The Model Context Protocol (MCP) carries structured evidence and tool responses. Application logic checks the evidence and applies the contract. Within the evaluated integration path, a model's `APPROVED` candidate cannot override a contract-required review.

The package accompanies *Separating Evidence Transport from Auto-Pass Authority in Laboratory-Linked Prescription Review: A Technical Evaluation of an MCP Implementation*. It contains executable code, the current manuscript's aggregate results and figures, and a separately identified historical public synthetic dataset. Version **2.0.2** was prepared as a local candidate on 6 September 2026. This package label does not assert a published GitHub tag or a DOI.

## What the evaluation found

The comparison held prompts, candidates, scores, and model forward passes constant across evidence-access and contract-governed paths. It used three models: Qwen2.5-3B-Instruct, SmolLM2-1.7B-Instruct, and Phi-3.5-mini-instruct. The manuscript reports a balanced, restricted 660-record technical set mapped from 1,540 deidentified source records: 264 pharmacist-anchored cleaned records, 264 protocol-defined observable faults, and 132 oracle-relative provenance substitutions across 11 drug-laboratory domains.

- On observable faults, the contract revoked all **37/37** Phi evidence-access auto-pass opportunities. This is conditional enforcement coverage. Qwen and SmolLM2 offered no such opportunities, so their coverage was not estimable.
- On cleaned records, Phi reference-discordant auto-pass changed from **2/132 to 0/132**, while unnecessary review changed from **23/132 to 24/132**. Domain-bootstrap intervals describe variation across the included domains; they are not population confidence intervals.
- A separate public synthetic assay fixed the candidate to `APPROVED`. The contract revoked **264/264** observable faults, with **44/44** per fault type, **24/24** per domain, and direct-MCP agreement in **528/528** records. It preserved auto-pass in only **120/132** reference-approved clean controls. A frozen generic non-mg dose-unit check incorrectly escalated all **12 heparin controls**. This defect remains in the evaluated contract.

The hidden-provenance boundary remained exposed: Phi auto-passed **110/132** oracle-relative substitutions after governance. Low rates in the other models reflected pervasive review rather than recovered provenance. No path containing a language model improved the observed protocol-concordance–review-workload balance over deterministic rules. Residual model value and clinical benefit were not established.

In the separate stratified 132-record public synthetic sensitivity assay, reversing candidate order changed **0/132** decisions for every model. Alternative labels, A/B mappings, or prompt wording changed up to **54**, **132**, and **28** decisions for Qwen, SmolLM2, and Phi, respectively. The normalized forced-choice score is configuration-specific and is not calibrated clinical confidence.

## Evidence and data access

The root `outputs/` directories preserve the aggregate evidence and figures distributed with the current supplementary software. [EVIDENCE_MAP.md](EVIDENCE_MAP.md) maps these files to manuscript tables, figures, and supplementary sections. Aggregate agreement allows readers to inspect the reported numbers; it does not independently verify the confidential source-to-analysis mapping.

`legacy/public_synthetic_20260728/` contains **20 original, byte-preserved files** from the historical public synthetic experiment, together with a README and `SOURCE_MANIFEST.json`. These are authorized public, entirely synthetic records, prepared inputs, and per-model scores and decisions. The two JSONL files sit beside `models/<alias>/`, preserving the three-model structure. Their source is the historical [tag 1.1](https://github.com/BOYA1999/When-Laboratory-Evidence-Is-Incomplete-Who-May-Approve/tree/1.1), [commit 3d7fdda](https://github.com/BOYA1999/When-Laboratory-Evidence-Is-Incomplete-Who-May-Approve/commit/3d7fdda0164a82d72615e0e5fed40342921cc227). The manifest records the original checksums. Synthetic reference fields are not pharmacist ratings on clinical records.

The legacy materials cannot replace the restricted **1,540-to-660** mapping, source-to-variant links, model-ready clinical records, clinical MCP contexts, or individual pharmacist labels. Those materials are absent. Restoring or reanalyzing legacy files supports synthetic software checks, not an independent patient-level rerun of the formal analysis. Historical names such as `unsafe_approval` and `confidence_threshold` remain in frozen files; the manuscript interprets them as reference-discordant auto-pass and score-threshold abstention.

Archived openFDA labels and the official Synthea sample archive are public source materials. Synthea person, encounter, address, and document-like identifiers are fictional. Runtime router and molecular components are ancillary to the 11-domain laboratory evaluation. See [DATA_SOURCES.md](DATA_SOURCES.md) for source provenance and redistribution boundaries.

## Installation and verification

Use a dedicated Python 3.12 environment from the extracted package root. On Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pytest -q tests
.\.venv\Scripts\python.exe tests_smoke.py
.\.venv\Scripts\python.exe scripts/verify_release.py
```

The test suite exercises deterministic behavior, real MCP calls, caller failure handling, and public synthetic authority checks. The standalone smoke test is a separate entry point. Release verification checks the packaged evidence and manifests. These checks require no clinical records or language-model checkpoints.

To inspect the local MCP interface with an MCP client:

```powershell
.\.venv\Scripts\python.exe mcp_server.py --transport stdio
```

`AUTO_PASS_ELIGIBLE` is an internal software state, not prescribing or dispensing authorization. This research implementation has not been evaluated for clinical deployment.

## Figures and optional reruns

Keep the distributed package unchanged and work in a disposable copy. The following command regenerates eight PNG/PDF figure pairs from bundled aggregates and coded schematics:

```powershell
python scripts/plot_lab_evidence_study.py
```

It writes to `outputs/lab_evidence_figures_v2/`. Rendering can vary with software and fonts; check the resulting pages and numerical labels.

Advanced analysis scripts use fixed output locations, immutable stages, and, where inference is involved, specific model snapshots. Before using them in a disposable copy, restore the historical synthetic intermediate files:

```powershell
python scripts/restore_public_surrogate.py
```

Restoration does not reconstruct clinical data. Read the script-specific contracts in [EVIDENCE_MAP.md](EVIDENCE_MAP.md) before selecting phases or outputs. Existing result directories can cause intentional overwrite refusals; some summarizers overwrite their fixed destination. The scoring-sensitivity audit uses locally cached tokenizers and can run offline on CPU; its scoring phase requires CUDA and bfloat16. Its summary phase also requires locally generated condition-level scores absent from the 20 legacy files. Model reruns need separately obtained checkpoints and compatible PyTorch. The September snapshot hashes and public-run environment records do not constitute a model lock for the restricted formal run.

## Integrity and licensing

`MANIFEST_SHA256.csv` records packaged file sizes and SHA-256 digests; the legacy source manifest records the original synthetic assets. `.gitattributes` preserves exact bytes across Git checkouts, including line endings. Repository-authored code uses the [MIT License](LICENSE). Third-party data, software, and models retain their own terms. Consult [MODEL_SOURCES.md](MODEL_SOURCES.md) and [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) before model use or redistribution. Language-model weights are not included.
