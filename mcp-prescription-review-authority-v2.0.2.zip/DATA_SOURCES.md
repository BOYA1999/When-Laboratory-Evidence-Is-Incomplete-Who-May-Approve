# Data Sources and Redistribution Boundary

This public package contains no prescription-level clinical records. The underlying study used retrospectively collected records from a clinical system after deidentification, re-keying, cleaning, and standardization. Detectable-fault and silent-substitution conditions were prespecified experimental transformations. Ethics and institutional data-use restrictions do not permit public release of the record-level data or pharmacist labels.

## Archived public inputs

| Material | Packaged path | Upstream source | Rights and boundary |
| --- | --- | --- | --- |
| Drug labeling records | `data/public/raw/lab_domain_openfda_labels.json`, `openfda_labels_200.json`, `sentinel_openfda_labels.json` | [openFDA Drug Label API](https://open.fda.gov/apis/drug/label/) | Generally public domain and CC0 unless an item is specifically marked otherwise. FDA requests attribution and disclaims clinical use. |
| Synthetic EHR sample | `data/public/raw/synthea_sample_data_csv_apr2020.zip` | [Synthea sample data](https://github.com/synthetichealth/synthea-sample-data) | Used for non-identifying templates and software tests, not as the study's clinical reference. Synthea is distributed under Apache-2.0; retain upstream notices. |
| Compound structures | `prescription_mcp/data/public_structures.json` | [PubChem PUG REST](https://pubchem.ncbi.nlm.nih.gov/docs/pug-rest) | NCBI places no general restriction on molecular database use, but contributor-specific rights and provenance may apply. The packaged file is limited to identifiers and structure strings used by this prototype. |

Retrieval URLs, timestamps, file sizes, and source-file hashes are retained in `data/public/source_manifest.json` where available. The laboratory-label archive also stores query provenance.

## Derived public research data

- `data/public/processed/` contains policy-labeled router examples derived from public openFDA text and Synthea indicators.
- `data/molecular/pair_provenance_public_60.csv` contains public compound identifiers and pair definitions.
- `outputs/` contains the unchanged aggregate tables, integrity metadata, public software assays, and figure exports accompanying the current manuscript; `EVIDENCE_MAP.md` identifies the scope of each result.
- `legacy/public_synthetic_20260728/` contains 20 author-confirmed public, purely synthetic files from the 28 July software run: two JSONL files and 18 model-score/decision files. Their exact bytes are checked against the earlier public commit. They are not the restricted clinical cohort or its pharmacist reference.
- Restricted clinical prescription records, prepared clinical contexts, individual clinical model scores and decisions, and pharmacist case-level labels are not distributed. The public synthetic files cannot reconstruct the 1,540-to-660 clinical lineage or independently verify that analysis.

The Synthea archive contains fictional person, encounter, address, and document-like identifiers, not real individuals. Retained public run dates and later public model snapshots are not evidence of the timing or model lineage of the restricted clinical run.

The MIT license applies only to repository-authored code and derived materials to the extent the contributors can license them. It does not replace upstream rights, model licenses, database notices, patents, trademarks, or contributor-specific PubChem terms.

## Required cautions

- Do not attempt to reconstruct or re-identify the restricted clinical records from aggregate results.
- Do not use openFDA content as a substitute for professional medical advice.
- Do not infer prevalence or hospital performance from the selected and experimentally perturbed benchmark.
- Reusers are responsible for checking the current upstream terms before redistribution or commercial use.
